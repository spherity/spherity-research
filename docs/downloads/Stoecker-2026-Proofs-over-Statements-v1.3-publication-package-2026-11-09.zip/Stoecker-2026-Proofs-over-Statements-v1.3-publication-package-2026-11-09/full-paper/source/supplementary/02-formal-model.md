# 02 A formal model of verifiable evidence graphs: graph semantics, proof domains, cost and assurance

> **Status note (7 November 2026).** Earlier design note, superseded by the manuscript `05-paper-draft.md` (v7). Labels, numbering and some results differ from the manuscript (for example P1–P10 here correspond to CP1–CP10 in the paper; the formal model and use-case numbers were revised in review rounds 1 and 2). Kept as a record of the derivation; the manuscript is authoritative.

Working paper, step 2 of 4. Status: draft, 7 November 2026.
References [n] point to the list in 01-requirements.md, plus [41]–[44], [67] and [C1]–[C7] at the end of this file. **[A]** marks an assumption. Every theorem lists the assumptions it uses.

---

## 0. Storyline

The argument has four links. Each link is one result.

1. **The requirements force graph semantics** (Theorem T1). The cross-domain properties of 01 (relational facts, identity across issuers, shared meaning, order-independent composition, shared nodes and cycles) are satisfied exactly by sets of statements over global identifiers combined by union: the RDF abstract syntax. Flat or tree-shaped attribute sets without global identifiers do not satisfy them.
2. **Graph semantics force the proof into the graph domain** (Lemmas L1, L2; Propositions P1–P3). Whether a fact stays verifiable after it is merged into a graph depends on what the signature is computed over. A proof over the canonical statements (architecture A) survives merging and re-serialisation and fails closed when meaning changes. A proof over the bytes of an envelope (architecture B, JSON-LD inside SD-JWT) does not survive merging, fails open when a context changes, and admits disclosure-dependent meaning.
3. **At scale, the graph-domain proof is also cheaper** (Theorem T2). A pays more per signature (canonicalisation), B pays more per re-verification (envelope plus JSON-LD expansion). There is an explicit break-even number of re-verifications. Above it, A dominates. Re-verification is what zero trust across company boundaries demands. The theorem also identifies where B wins: one-shot use and claim-level selective disclosure of identity attributes.
4. **Assurance is bounded by the weakest influential fact, and trust edges are always influential** (Theorem T3, Corollary C3). A conclusion can reach the qualified level only if every fact that can change it on its own, in particular every trust edge, is qualified at the point of use. By links 1 and 2, trust edges in an evidence graph must be graph-native credentials. Therefore the graph can reach the qualified level only if graph-native W3C credentials can be QEAA. Corollary C4 extends this across borders: imported evidence keeps its level only in a format both jurisdictions admit, and the format the US trade pilots, UN/CEFACT and Chinese cross-border pilots share is W3C VCDM in JSON-LD with DIDs. §7.7 applies T3 to the web's own JSON-LD knowledge graph, which is unverified today.

---

## 1. Preliminaries

**RDF.** Let $\mathcal I$ be the set of IRIs, $\mathcal B$ blank nodes, $\mathcal L$ literals, pairwise disjoint. A *statement* (triple) is $t=(s,p,o)\in\mathcal T := (\mathcal I\cup\mathcal B)\times\mathcal I\times(\mathcal I\cup\mathcal B\cup\mathcal L)$. A *graph* is a finite set $G\subseteq\mathcal T$. A *dataset* is $D=(G_0,\{(g_j,G_j)\}_{j})$ with a default graph $G_0$ and named graphs $G_j$ with distinct names $g_j\in\mathcal I\cup\mathcal B$ [13]. Two datasets are *isomorphic*, $D\cong D'$, if they are equal up to a bijective renaming of blank nodes [13].

**Merge.** The merge of graphs $G_1,\dots,G_k$ is the union after renaming blank nodes apart. A *provenance-preserving merge* places each $G_k$ into its own named graph: $M=\biguplus_k (g_k,G_k)$.

**Semantics.** Under RDF simple semantics the meaning of a graph is the set of interpretations that satisfy all its statements [41]. Isomorphic graphs have the same meaning. Adding statements can only remove satisfying interpretations, so entailment is monotone: if $G\models\varphi$ then $G\cup G'\models\varphi$ [41].

**Definition 1.1 (meaning of a document).** For a JSON-LD document $J$ and a context resolution function $\rho$ (mapping context URLs to context documents), let $E_\rho(J)$ be the dataset produced by JSON-LD expansion and conversion to RDF [12]. The *meaning* of $J$ under $\rho$ is $E_\rho(J)$ up to $\cong$. Two documents mean the same iff their datasets are isomorphic.

**Canonicalisation.** RDFC-1.0 [11] defines a function $\mathrm{C}$ from datasets to canonical N-Quads strings such that $\mathrm{C}(D)=\mathrm{C}(D')\iff D\cong D'$, provided it terminates. In the worst case (many indistinguishable blank nodes) it reduces to graph isomorphism, and the specification requires implementations to bound the work and abort on such inputs [11, §1, §4.4.3].

**Assumption A1 (bounded blank nodes).** The datasets admitted by the high-assurance profile have no blank nodes, or blank nodes that RDFC-1.0 distinguishes by their first-degree hashes. Then $\mathrm{C}$ is total on admitted datasets and costs $\kappa(n)=O(n\log n)$ for $n$ statements (serialisation, sorting, hashing). **[A]** Without A1, $\kappa$ can grow super-polynomially; T2 then fails for affected datasets (§6.4).

**Cryptography.** $H$ is a collision-resistant hash function. $\Sigma=(\mathsf{KeyGen},\mathsf{Sign},\mathsf{Verify})$ is existentially unforgeable under chosen-message attack (EUF-CMA): without the secret key, no efficient adversary produces a pair $(m,\sigma)$ with $\mathsf{Verify}(pk,m,\sigma)=1$ for an $m$ that was not signed, except with negligible probability. **[A]** standard.

---

## 2. Objects

### 2.1 Identifiers

Global identifiers are IRIs. Entities that are referenced by more than one issuer (organisations, products, sites, agents, credentials, vocabulary terms) carry IRIs, for example an EUID or LEI-based IRI, a GS1 Digital Link, a DID, or an HTTPS URL. Blank nodes denote existentially quantified entities local to one document. DIDs are IRIs whose resolution yields a DID document with verification methods (W3C DID Core 1.0 [42]); the model treats them like other IRIs and treats key resolution separately (§2.4).

### 2.2 Contexts and vocabularies

A *context* is a JSON-LD document that maps terms to IRIs [12]. A *vocabulary* is a set of IRIs for classes and properties, optionally with RDFS/OWL axioms and SHACL shapes [31]. A context reference in a document is *pinned* if the signed data contains a digest of the context document and verifiers reject documents whose resolved context does not match it (VCDM 2.0 `relatedResource` with `digestSRI` or `digestMultibase` [9]; Data Integrity resource integrity [10, §2.3]).

### 2.3 Credentials and links

A *credential* is $c=(\mathit{id}_c,i_c,D_c,\pi_c)$: identifier, issuer, a dataset of claims and metadata, and a proof. A *digest link* from $c$ to $c'$ is a statement in $D_c$ that references $\mathit{id}_{c'}$ together with a digest $d=H(\mathrm{Prep}(c'))$ of the prepared form of $c'$ (§3.1). The link is *valid* iff the referenced credential's prepared form hashes to $d$. A set of credentials with their digest links forms a directed graph $\Gamma$ (the "chain of attestations" of EBW Art. 5(1)(g) [1], generalised to a graph).

### 2.4 Issuers, keys, trust anchors

Each issuer $i$ controls signing keys. A *key resolution* function $\mathrm{res}$ maps a verification method referenced in a proof to a public key and a *trust path* ending in a trust anchor. For the qualified tier, anchors are the trust service entries in national trusted lists, and the path is an X.509 certification path [3]; a DID or HTTPS key reference can be bound to such a path **[A: the high-assurance profile must define this binding; open item]**. A *trusted list* $\mathrm{TL}$ is a finite set of entries $(\text{service},pk,\text{type},\text{status})$.

Two kinds of trust path occur in practice and fit the same model: (i) X.509 paths to trusted-list entries (eIDAS); (ii) DID resolution, where a DID document lists verification methods and the DID itself is bound to an organisation by another attestation (for example did:web under a domain, or did:webvh with a verifiable history [01: 45, 46]). DID resolution supplies the key; it does not by itself supply the issuer's level. The level comes from the attestation that binds the DID or key to a qualified anchor. The model therefore needs only $\mathrm{res}$ to return a key and a path; whether the path runs through X.509, a DID document, or both is a profile choice.

**Definition 2.0 (pluggable anchor sources).** A relying party's anchor configuration is a finite set $\mathcal S=\{S_1,\dots,S_m\}$ of *anchor sources*, each with a lookup function $\mathrm{look}_{S}(pk,\text{claim type})\in\{\text{accept},\text{reject},\text{unknown}\}$ and a ceiling $\ell(S)\in\Lambda$ fixed by law or by the relying party's policy. Examples:

| Anchor source | Lookup | Ceiling $\ell(S)$ |
|---|---|---|
| eIDAS national trusted lists (X.509) [3] | certificate path to a qualified service entry | $Q$ for qualified services |
| Qualified electronic ledgers (eIDAS Art. 45h, 45i) [3] | registration of issuer key or status on a qualified ledger | $Q$ for the ledger's integrity and ordering properties; issuer authority still needs a qualified attestation **[A]** |
| EBSI Trusted Issuers Registry [67] | accreditation chain of the issuer in the registry | as recognised by the relying party; $\le E$ unless backed by a qualified attestation **[A]** |
| Third-country lists recognised under eIDAS Art. 14 | per agreement | as agreed |
| Sector or ecosystem registries (e.g. a DSCSA credential-issuer list, UNTP trust anchors, data-space registries) | per ecosystem rules | $\le E$ in eIDAS terms; sector-specific legal weight possible |

The issued level becomes $\lambda(c)=\min\big(\max_{S:\ \mathrm{look}_S=\text{accept}}\ell(S),\ \lambda_{\mathrm{fmt}}(c)\big)$, where $\lambda_{\mathrm{fmt}}(c)=Q$ iff $\mathrm{format}(c)\in\mathsf{Adm}_Q$ and $E$ otherwise. None of the theorems depends on which sources are configured: L1, L2 and T2 are independent of anchors, and T3 and C3 use only $\lambda$. Adding an anchor source can raise the level of facts it covers only up to the format ceiling $\lambda_{\mathrm{fmt}}$, which is why C3 turns on $\mathsf{Adm}_Q$ and not on the choice of trust list.

### 2.5 Assurance levels and admissible formats

Let $\Lambda=\{\bot<U<E<Q\}$:
- $Q$: qualified (QEAA, PuB-EAA, qualified seal), with the legal effect of eIDAS Art. 45b [3];
- $E$: issuer-signed and verifiable, not qualified (EAA, other attestations);
- $U$: unsigned, with provenance recorded inside one trust domain (tier T0);
- $\bot$: no attributable source.

Let $\mathsf{Adm}_Q$ be the set of formats in which a QEAA or PuB-EAA may be issued. Under CIR 2026/1735 and 2026/1731, $\mathsf{Adm}_Q=\{\text{IETF SD-JWT VC},\ \text{ISO mdoc}\}$ (clauses 2–6 of TS 119 472-1 V1.2.1) [4][5][6].

**Definition 2.1 (issued level).** $\lambda(c)=Q$ iff the issuer's key resolves to a qualified anchor, the service is qualified for that attestation type, and $\mathrm{format}(c)\in\mathsf{Adm}_Q$. $\lambda(c)=E$ iff the proof verifies under a key with a trust path accepted by the relying party, and $\lambda(c)\neq Q$. Lower levels as above. Every fact $t\in D_c$ inherits $\lambda(t)=\lambda(c)$.

So **a W3C VCDM credential secured with Data Integrity has $\lambda\le E$ today**, whoever issues it.

### 2.6 The attribute-set model

**Definition 2.2.** In the *attribute-set model* $\mathcal F$, a document is a finite JSON value [43] whose top level is an object of claims about one implicit subject. Claim names are strings whose meaning is fixed per credential type (SD-JWT VC: `vct` and type metadata [15]; mdoc: `doctype` and namespaces [16]). JSON values are finite trees; JSON has no reference mechanism [43].

IETF SD-JWT VC and ISO mdoc instantiate $\mathcal F$. An $\mathcal F$-document can carry identifiers of other entities as string values, but the format assigns them no identity semantics.

### 2.7 Relying parties, policies, decisions

A *trust policy* $\mathsf{Pol}$ assigns to each *slot* (the role a fact plays in a decision, e.g. "legal representative of supplier", "recycled-content share", "maximum permitted torque") a set of acceptable issuer classes and a required level $\lambda_{\mathrm{req}}(\text{slot})\in\Lambda$. A *decision procedure* $\Pi$ is a deterministic function from a set of accepted facts to an outcome in a finite set $O$.

---

## 3. Requirements as formal conditions

Let a *representation scheme* be $\mathcal R=(\mathrm{Doc},\oplus,[\![\cdot]\!])$: a set of documents, a combination operator, and a semantics mapping each document to a set of atomic facts $r(e_1,\dots,e_n)$ over a universe of entities and values.

| Condition | From 01 | Formal statement |
|---|---|---|
| R-G relational | P1 | $[\![\cdot]\!]$ can express atomic facts of any arity $n\ge 2$ whose arguments are entities described in other documents. |
| R-I identity across issuers | P2 | A reference to an entity denotes the same entity regardless of which issuer's document contains it; no issuer-pair mapping is needed. |
| R-M shared meaning | P4 | The denotation of a predicate name does not depend on the issuer that uses it. |
| R-O open-world composition | P3 | $\oplus$ is commutative, associative and idempotent, and $[\![d_1\oplus d_2]\!]=[\![d_1]\!]\cup[\![d_2]\!]$ (no loss, no invention). |
| R-C sharing and cycles | P6 | The scheme represents finite relational structures with nodes of in-degree $>1$ and with directed cycles, without duplicating entities. |
| R-P per-fact provenance | P5 | Defined in §4.3 as per-fact verifiability after merge. |
| R-A assurance | P7 | Defined in §7 as attainable assurance of decisions. |

---

## 4. Theorem T1: the requirements imply a graph model

**Theorem T1.** (a) If $\mathcal R$ satisfies R-G, R-I, R-M and R-O, then there is an injective, meaning-preserving encoding $\mathrm{enc}$ of documents into finite sets of triples over global names, blank nodes and literals, with $\mathrm{enc}(d_1\oplus d_2)\cong\mathrm{enc}(d_1)\cup\mathrm{enc}(d_2)$ after blank nodes are renamed apart; that is, $\mathcal R$ is a serialisation of the RDF abstract syntax with merge. Triple sets satisfy R-C.
(b) The attribute-set model $\mathcal F$ violates R-I, R-M (unless names are globally qualified), R-O and R-C. Every extension of $\mathcal F$ that satisfies them adds global identifiers for entities, global names for predicates and references by identifier, and is then a serialisation of a triple set (JSON-LD is one such serialisation).

*Assumptions:* none beyond the definitions.

**Proof of (a).**
1. *Reduction to binary statements.* By R-G, $[\![d]\!]$ is a set of atoms $r(e_1,\dots,e_n)$. For $n=2$ write $(e_1,r,e_2)$. For $n>2$ introduce a fresh node $x$ and write $(x,\mathtt{type},r),(x,\mathtt{arg}_1,e_1),\dots,(x,\mathtt{arg}_n,e_n)$. Attribute facts $a(e,v)$ with a value $v$ are the binary case with a literal object. The map is injective up to the choice of fresh nodes, and the original atom is recovered by reading back the $\mathtt{arg}_j$ statements of $x$. Taking $x$ as a blank node, the fresh choice is immaterial up to $\cong$.
2. *Global entity names.* By R-I, a reference that appears in documents of different issuers denotes one entity independently of the issuer. So such references are names with an issuer-independent denotation. IRIs are such names. Entities referenced in only one document may be blank nodes, because R-I constrains only references shared across documents.
3. *Global predicate names.* By R-M, the same holds for predicates: predicate names have an issuer-independent denotation, i.e. they are IRIs.
4. *Composition is union.* By 1–3, $\mathrm{enc}(d)$ is a finite triple set. By R-O, $[\![d_1\oplus d_2]\!]=[\![d_1]\!]\cup[\![d_2]\!]$. Encoding both sides with blank nodes of $d_1$ and $d_2$ renamed apart (blank nodes are existential per document, so renaming preserves meaning) gives $\mathrm{enc}(d_1\oplus d_2)\cong\mathrm{enc}(d_1)\cup\mathrm{enc}(d_2)$. Union is commutative, associative and idempotent, matching R-O.
5. *R-C.* A triple set is a directed labelled graph; any node can have several incoming edges and cycles are allowed. ∎

**Proof of (b).** Each violation is shown by a counterexample, followed by what is needed to repair it.
1. *R-M (name collision).* Issuers $i_1,i_2$ issue documents of types $v_1\neq v_2$ about the same subject, both with a claim `status`, meaning legal status in a company register ($v_1$) and account status in a portal ($v_2$). A combined attribute map holds one value per name. Either one value is dropped (violating "no loss" in R-O), or the names are qualified by type, $v_1\#\mathtt{status}$ and $v_2\#\mathtt{status}$. Since `vct` values are required to be collision-resistant names [15], the qualified names are global predicate names, which is step 3 of (a).
2. *R-I (entity identity).* $\mathcal F$ documents are about one implicit subject; other entities appear as nested objects. Two issuers describe the same supplier as nested objects with identical attributes. Equal attribute values do not establish identity: two distinct entities can share every disclosed attribute (two subsidiaries with the same name in different registers). So the merged representation cannot decide whether one or two suppliers are meant. Repair: a global identifier on the nested object, which is step 2 of (a).
3. *R-C (sharing and cycles).* A JSON value is a finite tree [43]: every node has exactly one path from the root. A node with in-degree 2 must be represented twice. A directed cycle has an infinite unfolding and cannot be represented as a finite tree. Repair: references by identifier, which turns the tree into a graph.
4. *R-O.* Combination of JSON objects with shared keys (merge, patch, overwrite) is not commutative in general: $\{a{:}1\}\oplus\{a{:}2\}$ yields $\{a{:}2\}$ or $\{a{:}1\}$ depending on order. Commutativity and idempotence with no loss require multi-valued facts keyed by (subject, predicate), i.e. a set of triples. ∎

**Remarks.**
1. T1 is a statement about semantics, not syntax. JSON is a fine syntax for a graph; JSON-LD is exactly the JSON syntax with global identifiers, global names and references [12].
2. Once an $\mathcal F$-format is given global identifiers and a mapping from (type, claim name) to predicate IRIs, it also denotes a graph. Then the open question is no longer the data model but the proof: is the proof bound to the statements or to the bytes? This is §5.
3. T1 does not single out RDF among all conceivable graph models. RDF is the standardised instance with open-world model-theoretic semantics [13][41], a JSON syntax [12], canonicalisation [11] and the industrial ecosystem listed in 01 §5. Labelled property graphs (ISO/IEC 39075 GQL) do not provide global identifiers or open-world semantics by default **[A]**.

---

## 5. Two architectures and their proof domains

### 5.1 Proof domains

**Definition 5.1.** A securing mechanism is $\mathsf M=(\mathrm{Prep},\mathsf{Sign},\mathsf{Verify})$, where $\mathrm{Prep}$ maps a representation $r$ to the message actually signed. Its *proof domain* is the equivalence $r\sim_{\mathsf M} r'\iff \mathrm{Prep}(r)=\mathrm{Prep}(r')$.

By EUF-CMA, a proof made on $r$ verifies on $r'$ iff $r\sim_{\mathsf M} r'$ (except with negligible probability). Three domains occur:

| Domain | Mechanisms | $\mathrm{Prep}$ | Invariant under |
|---|---|---|---|
| Bytes | JWS, SD-JWT [14], SD-JWT VC [15], VC-JOSE-COSE [44], COSE/mdoc MSO [16] | identity on the signed byte string | nothing |
| JSON value | Data Integrity with JCS cryptosuites [10] | JSON canonicalisation | whitespace, key order |
| Graph | Data Integrity with RDFC cryptosuites (`eddsa-rdfc-2022`, `ecdsa-rdfc-2019`) [10][11] | $\mathrm{C}(E_\rho(J))$, or $\mathrm{C}(D)$ from a dataset | every RDF-equivalent serialisation: JSON-LD in any compaction or framing, N-Quads, Turtle, a triple store |

### 5.2 Architectures

**Architecture A (graph-native).** Credentials are W3C VCDM 2.0 documents [9] secured with a Data Integrity proof in the graph domain [10][11]. Links carry digests of canonical datasets. Consumers store each credential as a named graph with its proof graph [10, §2.1.3] in a dataset $M$.

**Architecture B (nested hybrid).** A JSON-LD document $J$ is the payload of an enveloping proof in the bytes domain. Two variants:
- B1: $J$ inside an IETF SD-JWT VC, carrying both `vct` and `@context` [15]. This is the variant that fits the current qualified baseline ($\mathsf{Adm}_Q$).
- B2: W3C VCDM secured with an enveloping JOSE/COSE proof (JWT or SD-JWT) via VC-JOSE-COSE [44]. This falls under the VCDM profile (clause 7) of TS 119 472-1, which the CIR does not reference [4][6]. UNTP currently mandates this variant (`vc+jwt`) [01: 47].

B2 shares A's data model (VCDM 2.0, JSON-LD), so B2 credentials interoperate with A at the level of meaning; L2 and T2 apply to B2 as to B1, while P1 (two type systems) does not.

**Consequence for UNTP.** UNTP's purpose is linked trade evidence ("trust graphs" of passports, conformity credentials and traceability events) [01: 20, 47]. Its consumers merge credentials from many issuers, so L2 applies: with the enveloping proof, the facts in the merged trust graph carry no proof of their own. This paper therefore recommends that UNTP adopt Data Integrity with an RDFC cryptosuite as the securing mechanism for credentials that are meant to be linked, and keep VC-JOSE only where a credential is consumed as a whole and not merged.

After verification, a B-consumer obtains the graph as $E_\rho(J')$, where $J'$ is the payload reconstructed from the disclosed parts.

### 5.3 Per-fact verifiability after merge (R-P)

**Definition 5.2 (PFV).** A mechanism has *per-fact verifiability after merge* if there is an efficient algorithm $V^\ast$ that, given only a provenance-preserving merged dataset $M$ (with proofs stored in $M$ as RDF), a statement $t$ and the trust anchors, accepts iff some $(g_k,G_k)\in M$ contains $t$ and carries a valid proof by an issuer with an accepted trust path.

**Lemma L2 (proof survives merge only in the graph domain).**
(a) Architecture A has PFV.
(b) No bytes-domain mechanism that uses salted disclosures (SD-JWT, mdoc) has PFV. A bytes- or JSON-domain mechanism without salts has PFV only if the issuer's serialisation is a deterministic function of the dataset, in which case it is a graph canonicalisation in disguise.
(c) If B stores the envelope bytes in $M$ as an opaque literal, verifying $t$ needs re-parsing, re-verification and re-expansion of the envelope plus a check that $E_\rho(J')\cong G_k$. The statements in $G_k$ themselves remain unproven.

*Assumptions:* EUF-CMA, collision-resistant $H$, A1.

*Proof.* (a) $V^\ast$ takes $G_k$ (mapping the named graph back to the default graph, a bijection), the proof graph and its options, computes $m=H(\mathrm{C}(\text{proof options}))\,\|\,H(\mathrm{C}(G_k))$ as in [10], resolves the key and runs $\mathsf{Verify}$. Merge renames blank nodes only, so $G_k\cong D_{c_k}$, hence $\mathrm{C}(G_k)=\mathrm{C}(D_{c_k})$ and $m$ equals the issuer's signed message. Completeness follows. Soundness: acceptance of a $t$ that the issuer did not sign would yield either a forgery of $\Sigma$ or an $H$-collision.

(b) In SD-JWT, the signed message $m$ contains, for each selectively disclosable claim, the digest $H(\mathit{disclosure})$ of a disclosure that contains a random salt; RFC 9901 recommends at least 128 bits [14]. In mdoc, each issuer-signed item contains a random value and the MSO signs the item digests [16]. The salts are not part of the expanded graph, and given the graph they are uniformly distributed. $V^\ast$ must present a message on which the proof verifies. By EUF-CMA it must present $m$ itself, which requires every salt in it; from $M$ alone this succeeds with probability at most $2^{-128}$ per salted claim. For unsalted JWS or JCS, many byte strings or JSON values (term names, nesting, array forms, key order) expand to the same dataset; $V^\ast$ recovers $m$ only if a fixed, deterministic serialiser from datasets to messages is part of the mechanism, which is a canonicalisation of the dataset.

(c) Follows from (b): the only verifiable object is the stored envelope, so $V^\ast$ repeats envelope verification and expansion and compares graphs. ∎

**Division of labour.** L2 does not condemn envelopes. An envelope is suitable for what is transient: a presentation to one verifier, with holder binding and a nonce. It is unsuitable for what persists and is merged: the attested facts. The DSCSA credentialing model already follows this split: credentials with embedded proofs over their statements, presented inside a JWT for each verification request (01, §3.9).

**Lemma L3 (format boundaries).** Let $t$ be a statement in a graph-domain credential and let its authority fact $a\in\mathrm{Auth}(t)$ be issued in an attribute-set format secured in the bytes domain. At the point of use either (i) the relying party keeps the bytes of $a$'s credential and runs two pipelines, with the claims-to-statements mapping chosen by the relying party and signed by no issuer, or (ii) it maps the claims once and stores them, in which case $\lambda_{\mathrm{eff}}(a)$ is the relying party's level. *Proof.* T1(b): an $\mathcal F$ document carries no global identifiers, so the mapping is not part of what the issuer signed; L2(b): the credential has no PFV; hence the bytes are verified separately or the mapping result is a derived fact (§7.4). ∎ Consequence: the qualified trust edges and the self-asserted facts must share one format and one proof domain; only the trust edges need level $Q$ (see the paper, Corollary C1).

**Consequence.** In B, a fact in a merged graph has no proof of its own. Either the consumer keeps the envelopes beside the graph and pays the envelope path on every verification (cost in §6), or the fact's effective level at the point of use drops to $U$ (§7).

### 5.4 Semantic integrity

**Lemma L1 (fail-closed versus fail-open meaning).** Let $J$ reference context URLs that are not pinned. Let the resolution change from $\rho$ to $\rho'$ such that $E_{\rho'}(J)\not\cong E_\rho(J)$ (the meaning changes, Def. 1.1).
(a) In B, verification still succeeds and the consumer obtains $E_{\rho'}(J)$: the meaning changes under a valid proof (fail-open).
(b) In A, starting from $J$, verification fails except with negligible probability (fail-closed). Starting from a stored dataset, no context is resolved at all.
(c) If all contexts are pinned and pins are enforced, both architectures bind meaning at issuance.

*Proof.* (a) B's $\mathrm{Prep}$ is independent of $\rho$, so $\mathsf{Verify}$ is unchanged, while expansion uses $\rho'$. (b) A's verifier computes $\mathrm{C}(E_{\rho'}(J))\neq\mathrm{C}(E_\rho(J))$ because the datasets are not isomorphic; by collision resistance $H$ differs, and by EUF-CMA the proof does not verify. From a dataset, $\mathrm{Prep}=\mathrm{C}(D)$ uses no context. (c) A pinned context fixes $\rho$ on the referenced URLs. ∎

The same holds for undefined terms: JSON-LD expansion drops terms that the context does not define [12]. In B, a context change that un-defines a term silently removes facts under a valid proof. In A, it changes the dataset and fails verification. The working paper [28] makes the general point that uncontrolled semantic resolution is a risk in every format (SD-JWT VC type metadata and mdoc namespaces included); L1 shows that the graph-domain proof turns one class of these risks into a verification failure.

### 5.5 Two type systems

**Proposition P1.** In B1, a credential carries two type assertions: `vct` (with type metadata and JSON Schema) [15] and `@type` (RDF classes) [9]. Without a rule that fixes their relation, two conformant verifiers can reach different acceptance decisions on the same credential.

*Proof.* Let $V_1$ accept by `vct` and its schema, and $V_2$ by `@type` and a SHACL shape. Construct $c$ whose `vct` names a type whose schema the payload satisfies, while its `@type` names a class whose shape the expanded graph violates (or the converse). Both specifications are satisfied; $V_1$ accepts and $V_2$ rejects. Neither the SD-JWT VC draft [15] nor VCDM 2.0 [9] defines a precedence rule for this combination **[A: no such rule found in either text as of the cited versions]**. ∎

### 5.6 Selective disclosure

**Proposition P2 (disclosure soundness).** Call a mechanism *disclosure-sound* if every statement in the meaning of any valid presentation is a statement of the issuer's signed dataset.
(a) A with statement-level selective disclosure (`ecdsa-sd-2023`, or BBS) is disclosure-sound.
(b) B1/B2 with JSON-LD 1.1 is not disclosure-sound in general.

*Proof.* (a) The issuer expands and canonicalises before signing; the units of disclosure are canonical statements of $D_c$, so any disclosed set is a subset of $D_c$ [10]. (b) Counterexample using a type-scoped context, a JSON-LD 1.1 feature [12, §4.1.8]. Let the context map term `value` to `ex:v2`, and define for type `ex:Limit` a scoped context that maps `value` to `ex:v1`. The issuer signs, in an SD-JWT, the object `{"id":"ex:o","@type":"ex:Limit","value":5}` with the `@type` member selectively disclosable. Full disclosure means $\{(\mathtt{ex{:}o},\mathtt{rdf{:}type},\mathtt{ex{:}Limit}),(\mathtt{ex{:}o},\mathtt{ex{:}v1},5)\}$. A holder withholds `@type`; the presentation verifies, and its expansion is $\{(\mathtt{ex{:}o},\mathtt{ex{:}v2},5)\}$, a statement the issuer never made. ∎

A profile can forbid selective disclosure of `@type` and of anything that triggers scoped contexts. The point is that B needs such a rule because disclosure operates on syntax before meaning is fixed, while A discloses after meaning is fixed.

**Proposition P3 (granularity and cost).** (a) Every statement set disclosable in B (with recursive disclosure markings) is disclosable in A. (b) The cost differs in the opposite direction: in B, each disclosure costs one hash; in A with `ecdsa-sd-2023`, the issuer signs each non-mandatory statement and the verifier checks one signature per disclosed statement plus one base signature **[A: per the W3C ECDSA cryptosuites specification; to be confirmed against the Recommendation text]**.

*Proof sketch.* (a) A's units are single statements, the finest possible. (b) By construction of the cryptosuites. ∎

Consequence: claim-level selective disclosure of a small identity attribute set is cheaper in SD-JWT VC. This is the wallet-presentation case, where SD-JWT VC and mdoc should remain the default (01 §5).

---

## 6. Theorem T2: cost at scale

### 6.1 Cost primitives

For a credential with $n$ statements, $b$ bytes and $k$ selectively disclosable claims (all non-negative, measured per core):
- $x(n)$: JSON-LD expansion and conversion to RDF, contexts served from a local pinned cache;
- $\kappa(n)$: RDFC-1.0 canonicalisation of an $n$-statement dataset;
- $h$: hashing of the prepared message (absorbed into $\kappa$ or $p$ where convenient);
- $v$, $s$: one signature verification, one signature generation;
- $p(b,k)$: envelope processing (decode, parse, $k$ disclosure digests, reconstruction);
- $q(n)$: reading $n$ statements of one named graph from the consumer's store.

Single verification costs:

| Event | A | B |
|---|---|---|
| First ingestion from wire format | $A_0=x+\kappa+v$ | $B_0=p+v+x$ |
| Re-verification of a stored fact | $A_1=q+\kappa+v$ | $B_1=p+v+x$ (by L2(c)) |

Issuance: $I_A=x+\kappa+s$, $I_B=p'+s$ with $p'\le p$.

### 6.2 Workload

A credential is issued once, ingested once from wire format, and then verified $R$ more times. $R$ counts the verification events that the requirements force after first ingestion:
1. every crossing of a trust boundary (each receiving organisation verifies; zero trust, 01 term 3);
2. every point-of-use verification its policy demands (e.g. a safety controller loading or reloading its knowledge base, an agent acting on a fact);
3. every later audit or dispute (AI Act Art. 12, PLD) [22][24].

Verification results may be cached inside one trust domain; caching across domains is excluded by zero trust. **[A]**

**Modelling assumptions.**
- M1: in A, events 1–3 start from the graph-native form (justified by L2(a)); in B, they start from the envelope (forced by L2(b), (c)).
- M2: both architectures use locally cached, pinned contexts (no network fetch). This is favourable to B.
- M3: A1 holds.

### 6.3 Theorem

**Theorem T2.** Under M1–M3, let the total cost over issuance and $1+R$ verification events be
$$C_A(R)=I_A+A_0+R\,A_1,\qquad C_B(R)=I_B+(1+R)\,B_1 .$$
Let $\Delta_0=(I_A-I_B)+(A_0-B_0)=x+\kappa-p'+\kappa-p$ (A's extra cost up front) and $\delta=B_1-A_1=p+x-q-\kappa$ (A's saving per re-verification).
(i) If $\delta>0$, then $C_A(R)<C_B(R)$ for all $R>R^\ast:=\Delta_0/\delta$, and the per-fact saving tends to $\delta/n$ as $R\to\infty$.
(ii) If $\delta\le 0$, B is at least as cheap for every $R$.
(iii) For a fact base of $N$ credentials whose facts are consumed $F$ times in total, the verification work per consumed fact is $W_A=(N(I_A+A_0)+\sum_c R_c A_1)/F$ and $W_B=(N(I_B+B_0)+\sum_c R_c B_1)/F$; A has lower work per consumed fact iff $\sum_c R_c>N\Delta_0/\delta$, i.e. iff the average number of re-verifications per credential exceeds $R^\ast$.

*Proof.* $C_B(R)-C_A(R)=(I_B+B_0)-(I_A+A_0)+R(B_1-A_1)=R\delta-\Delta_0$. When $\delta>0$ this is positive iff $R>\Delta_0/\delta$. When $\delta\le0$ it is at most $-\Delta_0$, which is negative because $\Delta_0=x+2\kappa-p-p'>0$ whenever $p+p'<x+2\kappa$, i.e. whenever envelope processing costs less than one expansion plus two canonicalisations, which holds for any non-trivial credential. (iii) sums the same difference over credentials and divides by $F$. ∎

*Variant without issuance.* If issuance is excluded (the issuer's cost is not the consumers' concern), $\Delta_0^{v}=A_0-B_0=\kappa-p$ and $R^{\ast}_{v}=(\kappa-p)/\delta$.

### 6.4 When does $\delta>0$ hold?

$\delta>0\iff x(n)+p>\kappa(n)+q(n)$: *expanding JSON-LD and processing the envelope costs more than reading the statements from the store and canonicalising them.*

- Under A1, $\kappa(n)$ is serialisation, sorting and hashing of $n$ quads. $x(n)$ includes JSON parsing, context processing, IRI expansion per term and RDF conversion. **Hypothesis H1:** $x(n)>\kappa(n)+q(n)$ for blank-node-free credentials of realistic size. H1 is plausible but not proven here; 03 gives the benchmark protocol and illustrative numbers.
- If A1 fails (blank-node-heavy data), $\kappa$ can exceed $x$ and $\delta\le 0$. Design consequence for the high-assurance profile: give every node an IRI (no blank nodes), which also helps linking.
- Network-fetched contexts (violating M2) increase $x$ and favour A further.

**Illustration (symbolic, not measured).** With $p=p'=0.1x$, $\kappa=0.3x$, $q=0.05x$: $\Delta_0=x+0.6x-0.2x=1.4x$, $\delta=0.1x+x-0.05x-0.3x=0.75x$, $R^\ast\approx1.9$. Including issuance, A is cheaper from the second re-verification onwards; for consumers alone ($R^\ast_v=0.2x/0.75x\approx0.27$), from the first. With $\kappa=2x$ (blank-node-heavy): $\delta<0$, B is cheaper for every $R$.

**Measured.** The benchmark in 03 §1 (jsonld.js 8.3.3, rdf-canonize 4.0.1, Ed25519, credentials of 17–574 statements) finds H1 satisfied in every configuration where A re-verifies from parsed quads, with $R^\ast$ between about 5 and below 1 including issuance, falling with credential size. H1 fails for large credentials only when A re-parses its stored graph from N-Quads text with a parser whose duplicate check is quadratic, which confirms that M1 (graph-native storage) is a real precondition of T2 rather than a formality.

### 6.5 Scope of T2 and where B wins

1. **One-shot consumption** ($R=0$): B is cheaper by $\Delta_0$ (if $\kappa>p$). Typical for a wallet presenting identity to one relying party.
2. **Claim-level selective disclosure on every presentation**: B is cheaper (P3(b)). Typical for personal identification data and EBW owner identification data presented from a wallet.
3. **Steady-state latency inside one trust domain**: once a consumer has verified and cached, the point-of-use check reduces to a status check in both architectures. A's advantage lies in boundary crossings, re-sharing and audits, not in the cached hot path.

### 6.6 Repairing B and why it reduces to A

- *Dual proof by the issuer.* The issuer adds a graph-domain proof next to the envelope. Consumers of graphs then use only the graph-domain proof; the result is A plus the cost of B at issuance.
- *Re-signing by the consumer.* The consumer verifies the envelope once and re-signs the graph. The new proof attests that the consumer received the fact, not that the source asserted it. The issuer attribution in R-P is lost, and the fact's level becomes the consumer's level for a different statement (§7.4).

### 6.7 Complexity as a security property: verify what you use

Security engineering has long treated complexity as a source of insecurity. Schneier wrote in 1999 that "The worst enemy of security is complexity" [C1]. Hoare distinguished designs "so simple that there are obviously no deficiencies" from designs "so complicated that there are no obvious deficiencies" [C2]. The language-theoretic security (LangSec) work states as a principle that secure composition requires parser computational equivalence, and notes that equivalence is undecidable for sufficiently expressive input languages [C3]. Concrete evidence: parser differentials across 49 JSON parsers [C4], and the JOSE history of `alg: none` and algorithm-confusion vulnerabilities [C5][C6].

The nested hybrid is complex in a specific, formalisable way.

**Definition 6.1 (use-bound).** A verifier is *use-bound* if the object on which the proof is checked is the same object on which the relying party acts: $\mathrm{Prep}(r)$ is a function of the meaning $[\![r]\!]$ that the application consumes, and of nothing else.

**Proposition P4 (B is not use-bound; A is).**
(a) In A, the proof is checked on $\mathrm{C}(E_\rho(J))$, a function of the meaning; the security decision and the business decision use one interpretation.
(b) In B, the proof is checked on bytes, while the application acts on $E_\rho(\mathrm{reconstruct}(J,S))$, produced by further interpreters (disclosure reconstruction, JSON-LD expansion with $\rho$, and in B1 the `vct` type metadata). Acceptance therefore rests on the agreement of independently specified interpretations of the same input. L1 (context change), P1 (`vct` versus `@type`) and P2 (withheld `@type` changing the meaning of a disclosed member) are three instances of their disagreement.
(c) By the LangSec result, agreement between such interpreters cannot be established in general by testing; it must be imposed by profile rules (pin every context, forbid disclosure of type triggers, fix a precedence between type systems), each of which is one more rule to specify, implement and audit.

*Proof.* (a) and (b) restate Def. 5.1 for each architecture; the instances are L1, P1, P2. (c) is the cited undecidability result applied to the composition of envelope, reconstruction and expansion. ∎

**Counter-evidence and its answer.** A is not free of interpretation risk. Data Integrity's own specification warns that undefined terms and relative URLs "can be dropped silently" during canonicalisation [10, §2.4.3], and a 2024 responsible disclosure showed context and `@vocab` manipulation attacks on Data Integrity, after which `@vocab` was removed from the VCDM 2.0 base context and context validation was made normative [C7]. LangSec itself recommends plain JSON over richer encodings [C3]. The answer is not that JSON-LD is simple. It is that in A these risks sit *before* the signature: they are decided once, at issuance, and anything that changes the meaning afterwards fails verification (L1). In B the same JSON-LD risks remain, because the consumer still expands the payload, and they sit *after* the signature, where they fail open. B therefore adds an envelope layer and its interpretations to the JSON-LD risks; it does not replace them. The high-assurance profile (pinned contexts, no `@vocab`, IRIs for all nodes, undefined terms rejected at issuance) addresses A's residual risks directly.

### 6.8 Processing layers

A requires one data model (RDF via JSON-LD) and one canonicaliser, in sequence. B1 requires an envelope processor (JOSE/SD-JWT), disclosure reconstruction, a JSON-LD processor and a type-metadata processor, two of which interpret the same input in parallel (P4).

---

## 7. Theorem T3: assurance propagation and the weakest link

### 7.1 Threat model

An adversary wants a decision procedure $\Pi$ to output an outcome $o'\neq o$, where $o=\Pi(S)$ on the honest accepted evidence $S$. It can inject facts or substitute facts in slots. It controls its own keys, so facts signed by its own keys cost nothing to produce, but $\mathsf{Pol}$ accepts a fact only if its issuer has the required authority (7.2).

**Cost of a false fact.** $K:\Lambda\to[0,\infty]$ with $K(\bot)=0\le K(U)<K(E)<K(Q)$ is the minimal cost of making the relying party accept a false fact at that level: at $U$, modifying data inside a pipeline or store; at $E$, compromising or deceiving a non-qualified issuer, or obtaining an attestation from an issuer without authority for the claim [28]; at $Q$, compromising or deceiving a supervised qualified trust service with conformity-assessed processes and verification against authentic sources [3]. **[A]** K is ordinal; only its order is used.

**Effective level.** $\lambda_{\mathrm{eff}}(t)$ is the level of the proof the relying party can verify for $t$ at the point of use. By L2, in B after merge $\lambda_{\mathrm{eff}}(t)=U$ unless the envelope is re-verified at that point.

**Policy liveness.** $\lambda_{\mathrm{req}}(\text{slot})\le\lambda_{\max}(\text{slot})$, where $\lambda_{\max}$ is the highest level at which honest issuers can issue that fact type in a format that satisfies the slot's structural needs (T1, L2). Otherwise the policy rejects honest evidence. **[A]**

### 7.2 Authority facts

For every third-party fact $t$, $\mathsf{Pol}$ requires a set of *authority facts* $\mathrm{Auth}(t)\subseteq S$ that establish the issuer's authority for $t$: e.g. "key $k$ belongs to a qualified service" (trusted list), "issuer $i$ is the register for company $x$", "signer $y$ holds a mandate from $x$ covering $t$'s scope", "laboratory $\ell$ is accredited for test type $\tau$". These are the *trust edges* of the evidence graph. They are facts with their own levels.

### 7.3 Theorem

A set $X$ of slots is *flipping* if replacing or adding facts in $X$ (and nowhere else) can make $\Pi$ output $o'$. A slot $t$ is *singly influential* if $\{t\}$ is flipping. The *attainable assurance* of the decision is $\alpha(o)=\min_{\text{successful attacks}}\text{cost}$.

**Theorem T3.**
(a) Lower bound: $\alpha(o)\ \ge\ \min_{X\ \text{flipping}}\ \sum_{t\in X}K(\lambda_{\mathrm{eff}}(t))\ \ge\ \min_{t\in\mathrm{Infl}}K(\lambda_{\mathrm{eff}}(t))$, where $\mathrm{Infl}$ is the union of minimal flipping sets.
(b) Upper bound (weakest link): $\alpha(o)\ \le\ \min_{t\ \text{singly influential}}K(\lambda_{\mathrm{eff}}(t))$.
(c) Trust edges: if $\Pi$ uses a third-party fact $t$ for which some adversary-signed substitute $t'$ would flip $o$, then the authority slot of $t$ is singly influential and $\alpha(o)\le K(\lambda_{\mathrm{req}}(\mathrm{Auth}(t)))\le K(\lambda_{\max}(\mathrm{Auth}(t)))$.
(d) Consequently, $\alpha(o)\ge K(Q)$ requires $\lambda_{\mathrm{eff}}=Q$ for every singly influential fact, in particular for every trust edge on which an influential third-party fact depends; and it is sufficient that $\lambda_{\mathrm{eff}}=Q$ for every fact in $\mathrm{Infl}$.

*Assumptions:* $\Pi$ deterministic and sound on honest evidence; K as above; policy liveness.

*Proof.* (a) A successful attack changes facts in some set $X$; since $\Pi$ is deterministic and $\Pi(S)=o$, $X$ must be flipping. Each changed fact must be accepted at its slot, which costs at least $K(\lambda_{\mathrm{eff}})$ of that slot by definition of $K$. Summing gives the first inequality; every flipping set contains an element of $\mathrm{Infl}$ and costs are non-negative, which gives the second.
(b) If $\{t\}$ is flipping, the attack that substitutes $t$ alone succeeds at cost $K(\lambda_{\mathrm{eff}}(t))$.
(c) The adversary signs $t'$ with its own key at no cost and injects an authority fact $a'$ that grants its key the authority $\mathsf{Pol}$ requires. The policy accepts $a'$ if it is accepted at level $\lambda_{\mathrm{req}}(\mathrm{Auth}(t))$, at cost $K(\lambda_{\mathrm{req}})$. Then $t'$ is accepted and $o'$ results, so the authority slot is singly influential. Liveness gives the second inequality.
(d) Necessity from (b) and (c), sufficiency from (a). ∎

**Interpretation.** A decision is never more assured than the cheapest fact that can change it on its own. Trust edges can change every decision that relies on any fact they authorise. So the level of the trust edges caps the level of the whole graph, however strongly the other facts are signed. Raising the trust edges to $Q$ raises the attainable assurance of every decision that depends on them; the T0/T1 facts elsewhere in the graph then determine the bound only where they are themselves influential, which is where the tier rule of 01 §6 places verification.

### 7.4 Derived facts and re-signing

A derived fact (T0) produced by a component $\Gamma$ from inputs $t_1,\dots,t_m$ is a slot whose substitution cost is $\min(K(\lambda(\Gamma)),\ \alpha\text{ of its inputs})$ by T3 applied to $\Gamma$ as a decision procedure. A consumer's re-signature (§6.6) creates a new fact "the consumer states that it received $t$" at the consumer's level; it cannot raise the level of $t$ itself above the level at which $t$ was verified, and it removes the source's attribution from the graph.

### 7.5 Corollary C3: W3C credentials must be admissible as QEAA

**Corollary C3.** Assume:
1. a decision $o$ depends on a trust edge $a$ that is relational (mandate chain, ownership and control structure, accreditation scope linking body, standard and product), so by T1 it needs graph form;
2. $\Pi$ evaluates the merged evidence graph at the point of use, and the relying party does not re-run envelope verification and expansion for every use (T2: $R$ large);
3. $\mathsf{Adm}_Q=\{\text{SD-JWT VC},\text{mdoc}\}$.

Then $\alpha(o)\le K(E)$, whichever way $a$ is issued:
- issued in A (W3C VCDM with Data Integrity): $\lambda(a)\le E$ by Def. 2.1, so $\alpha(o)\le K(E)$ by T3(c);
- issued in B1 as QEAA: by L2, $\lambda_{\mathrm{eff}}(a)=U$ in the merged graph, so $\alpha(o)\le K(U)$; re-verifying the envelope at each use restores $Q$ at cost $(1+R)B_1$ (T2), with residual fail-open semantics (L1, P1, P2) unless contexts are pinned and disclosure of type triggers is forbidden;
- flattened into $\mathcal F$ attributes: the relational edge must be reassembled by the consumer, i.e. it becomes a derived fact at the consumer's level ($\le E$ for third parties, $U$ internally) by §7.4.

Hence $\alpha(o)\ge K(Q)$ at graph-native cost is attainable only if graph-domain W3C credentials are in $\mathsf{Adm}_Q$. ∎

### 7.6 Corollary C4: the jurisdictional bridge

Let a relying party in jurisdiction $J_1$ consume a fact $t$ issued in $J_2$ (01, GI-1). Let $\mathsf{Adm}_Q^{J_1}$ be $J_1$'s admissible qualified formats and $\mathcal A^{J_1}$ its accepted anchors.

**Corollary C4.** (a) If $\mathrm{format}(t)\notin\mathsf{Adm}_Q^{J_1}$ or $t$'s trust path does not end in $\mathcal A^{J_1}$, then $\lambda_{\mathrm{eff}}(t)\le E$ in $J_1$, and every decision for which $t$ or its trust edge is singly influential has $\alpha\le K(E)$ (T3).
(b) If $t$ must be converted into a $J_1$ format by an intermediary, the converted fact is the intermediary's statement (§7.4); issuer attribution to the $J_2$ source is lost and the level is the intermediary's.
(c) The level can be preserved across the border only if both jurisdictions admit a common format and identifier scheme and $J_1$ recognises $J_2$'s anchors (for the EU: eIDAS Art. 14 agreements [3]).

*Proof.* (a) Def. 2.1 applied in $J_1$, then T3(b), (c). (b) §7.4. (c) Necessity from (a) and (b); sufficiency because a fact in a common format whose anchor is recognised satisfies Def. 2.1 in $J_1$. ∎

**Reading with 01 §3.9.** The common element across US trade pilots, UN/CEFACT guidance and Chinese cross-border pilots is W3C VCDM in JSON-LD with DIDs or other IRIs as identifiers. Under C4(c), admitting that data model to $\mathsf{Adm}_Q^{EU}$ is a precondition for imported evidence ever reaching level $Q$ in EU evidence graphs without an intermediary. C4 says nothing about which foreign anchors the EU should recognise; that remains a policy decision.

### 7.7 Example: decisions grounded in the web's knowledge graph

schema.org statements in web pages (01 §5.1) carry no issuer proof, so $\lambda_{\mathrm{eff}}\in\{\bot,U\}$. By T3(b), an automated decision for which such a statement is singly influential has $\alpha\le K(U)$: the cost of editing a web page. Adding a Data Integrity proof by an identified issuer to the same JSON-LD raises that statement to $E$, and to $Q$ once graph-native credentials are admissible as QEAA and the trust edge is qualified (C3). The data model and the publishing practice do not change; only the proof and the issuer's level do (Figure 1 in 01).

**What C3 does not say.** It does not say that QEAA status makes facts true, or that every fact must be qualified. It says that the trust edges must be qualified and graph-native at the same time, and that the current baseline offers either one or the other.

---

## 8. Summary of properties

| Property | A: graph-native (VCDM 2.0 + Data Integrity, RDFC) | B: nested hybrid (JSON-LD in SD-JWT) | Result |
|---|---|---|---|
| Graph semantics (R-G, R-I, R-M, R-O, R-C) | yes | yes, after expansion | T1 |
| Per-fact verifiability after merge (R-P) | yes | no; envelope must be kept and re-processed | L2 |
| Meaning bound by the proof | fail-closed; no context needed from a store | fail-open unless every context is pinned | L1 |
| Type system | one (`@type`) | two (`vct`, `@type`), no precedence rule | P1 |
| Disclosure soundness | yes | no without extra profile rules | P2 |
| Selective-disclosure cost | higher (one signature per statement with `ecdsa-sd-2023`) | lower (one hash per claim) | P3 |
| Cost, one-shot | higher by $\Delta_0$ | lower | T2(ii), §6.5 |
| Cost, $R>R^\ast$ re-verifications | lower by $R\delta-\Delta_0$ | higher | T2(i) |
| Use-bound verification (verify what you use) | yes | no; security and meaning decided by different interpreters | P4 |
| Processing layers | 1 data model + canonicaliser, in sequence | envelope + reconstruction + JSON-LD + type metadata | §6.8 |
| Attainable assurance at trust edges, today | $\le E$ (not in $\mathsf{Adm}_Q$) | $Q$ at the envelope, $U$ in the merged graph | T3, C3 |
| Attainable assurance if VCDM is admitted to $\mathsf{Adm}_Q$ | $Q$ at graph-native cost | unchanged | C3 |
| Imported evidence (US, UN, China pilots use VCDM/JSON-LD and DIDs) | can reach $Q$ if admitted and anchors recognised | B1 is an EU-only construction | C4 |

## 9. Assumptions and threats to validity

| ID | Assumption | Used in | How to test or weaken |
|---|---|---|---|
| A1 | Bounded blank nodes in admitted datasets | L2, T2 | Profile rule "IRIs for all nodes"; measure $\kappa$ on real credentials |
| H1 | $x(n)+p>\kappa(n)+q(n)$ | T2 | Benchmark protocol in 03 |
| M1 | A re-verifies from the store; B from the envelope | T2 | Follows from L2 |
| M2 | Local, pinned contexts | T2 | Relaxing favours A |
| — | EUF-CMA, collision resistance | L1, L2 | Standard |
| — | Key resolution of DI proofs to X.509 and trusted lists | §2.4, C3 | Must be specified in the high-assurance profile |
| — | Ordinal cost function $K$ | T3 | Only order used; no numbers claimed |
| — | Policy liveness | T3(c), C3 | Definitional |
| — | No precedence rule for `vct` vs `@type` | P1 | Re-check against final SD-JWT VC RFC and any ETSI profile |
| — | `ecdsa-sd-2023` cost structure | P3 | Confirm against the W3C ECDSA cryptosuites Recommendation |

Limitations:
- T2 is a cost comparison under a stated workload; it is not a measurement. Its conclusion depends on H1 and on $R$.
- T3 is a worst-case bound. It does not model probabilistic failure, corroboration by independent sources, or legal weighing of evidence by courts. It uses legal effect (Art. 45b) only as the reason why $Q$ is the top level of $\Lambda$.
- C3 is conditional on the current $\mathsf{Adm}_Q$. If the Commission references a W3C VCDM profile as foreseen in Recital 1 of CIR 2026/1731 [4], its third premise no longer holds and the bound lifts.

## Additional references (02)

[38] (reserved)
[C1] B. Schneier, "A Plea for Simplicity", 19 November 1999. https://www.schneier.com/essays/archives/1999/11/a_plea_for_simplicit.html
[C2] C. A. R. Hoare, "The Emperor's Old Clothes", Communications of the ACM 24(2), 1981, 75–83. https://doi.org/10.1145/358549.358561
[C3] L. Sassaman, M. L. Patterson, S. Bratus, A. Shubina, "The Halting Problems of Network Stack Insecurity", USENIX ;login: 36(6), December 2011. https://www.usenix.org/system/files/login/articles/105516-Sassaman.pdf
[C4] J. Miller (Bishop Fox), "An Exploration of JSON Interoperability Vulnerabilities", 2021. https://bishopfox.com/blog/json-interoperability-vulnerabilities
[C5] T. McLean, "Critical vulnerabilities in JSON Web Token libraries", 31 March 2015. https://auth0.com/blog/critical-vulnerabilities-in-json-web-token-libraries/
[C6] S. Arciszewski, "No Way, JOSE! Javascript Object Signing and Encryption is a Bad Standard That Everyone Should Avoid", 14 March 2017. https://paragonie.com/blog/2017/03/jwt-json-web-tokens-is-bad-standard-that-everyone-should-avoid
[C7] W3C VC Working Group, vc-data-integrity issue #272, "Multiple significant security vulnerabilities in the design of data integrity", 2024. https://github.com/w3c/vc-data-integrity/issues/272
[67] European Commission, European Blockchain Services Infrastructure (EBSI), Trusted Issuers Registry documentation. https://hub.ebsi.eu/ **[exact page to be confirmed]**
[41] W3C, RDF 1.1 Semantics, Recommendation, 25 February 2014. https://www.w3.org/TR/rdf11-mt/
[42] W3C, Decentralized Identifiers (DIDs) v1.0, Recommendation, 19 July 2022. https://www.w3.org/TR/did-core/
[43] IETF RFC 8259, The JavaScript Object Notation (JSON) Data Interchange Format, December 2017. https://www.rfc-editor.org/rfc/rfc8259
[44] W3C, Securing Verifiable Credentials using JOSE and COSE, Recommendation, 15 May 2025. https://www.w3.org/TR/vc-jose-cose/ **[date to be confirmed]**
