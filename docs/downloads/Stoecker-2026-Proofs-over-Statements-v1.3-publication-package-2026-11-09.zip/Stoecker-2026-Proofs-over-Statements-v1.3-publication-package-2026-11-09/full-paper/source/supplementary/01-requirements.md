# 01 Industry requirements for European Business Wallets: from domains to an evidence graph

> **Status note (7 November 2026).** Earlier design note, superseded by the manuscript `05-paper-draft.md` (v7). Labels, numbering and some results differ from the manuscript (for example P1–P10 here correspond to CP1–CP10 in the paper; the formal model and use-case numbers were revised in review rounds 1 and 2). Kept as a record of the derivation; the manuscript is authoritative.

Working paper, step 1 of 4. Status: draft, 7 November 2026. Author: Carsten Stöcker (Spherity GmbH), with drafting support.
Source policy: every factual claim cites a public source in the reference list at the end ([n]). Statements marked **[A]** are assumptions or the author's assessment, not sourced facts. No confidential working material (standardisation drafts, platform-internal documents, project data) is used.

---

## 1. Purpose and method

This section states, at a high level, what eight industrial application domains require from attestations exchanged through the European Business Wallet (EBW). It then derives the requirements they share. Section 02 turns the shared requirements into a formal model and proves that they imply a graph data model (Theorem T1).

Method:
1. Take the reference requirement (Section 2) as the yardstick.
2. For each domain, state the requirements that public legal texts, standards and specifications impose or that the domain's operation makes unavoidable.
3. Map each domain requirement to seven cross-domain properties (Section 4).
4. Derive the common core (Section 5) and the verification tiers (Section 6).

The domains overlap. A battery passport is both a DPP and a digital twin, and a production agent is agentic, industrial and physical AI at once. The separation serves to show that the same core requirements recur, not to draw boundaries.

## 2. Yardstick: the reference requirement

> Access-controlled, verifiable evidence graphs for physical products, virtual products and physical AI. Every fact links to its source, meaning and version; every operation links to an actor's authority and current permission. Built on open international standards and open-world semantics, as shared infrastructure across companies and jurisdictions.

| # | Term | Meaning used in this paper |
|---|---|---|
| 1 | Evidence graph | Facts are linked statements about many subjects, not isolated attribute lists. Attestations reference each other by identifier and digest. |
| 2 | Verifiable | Each fact that crosses a trust boundary is bound to its issuer, version and status. Verifiable means attributable, intact, versioned and revocable. It does not mean true. |
| 3 | Access-controlled | Every requested operation is evaluated against the requester's current permission (zero trust). |
| 4 | Open standards | Formats and protocols are open international standards, not tied to one platform. |
| 5 | Open-world | Parties can add facts later without changing existing schemas; meaning is shared through referenced vocabularies. |
| 6 | Accountable | Every operation, including those of devices and AI agents, traces back to a natural or legal person. |
| 7 | Shared | One infrastructure across companies and jurisdictions, not one stack per platform. |

Subjects: physical products, virtual products (software, data sets, models, services) and physical AI (machines, robots, embodied agents).

## 3. Domain requirements

Each domain lists its requirements (IDs used later in 02 and 03), the reason, and the source.

### 3.1 Business-to-business (B2B)

The EBW is designed for exchanges between economic operators and with public sector bodies [1]. Its own legal text goes beyond identity attributes:

| ID | Requirement | Source |
|---|---|---|
| B2B-1 | Attestations about an economic operator can be linked to other attestations "forming a chain" so that a relying party can verify them together. | EBW proposal Art. 5(1)(g) [1] |
| B2B-2 | Authorised representatives (natural or legal persons) act under mandates with defined scope. | EBW proposal Art. 3(18), 3(19) [1] |
| B2B-3 | An access control mechanism with roles, mandates and delegation governs who in the business may use which attestation for which purpose. | EBW proposal, Annex, section 12 [1] |
| B2B-4 | Attestations with legal effect: a qualified electronic attestation of attributes (QEAA) has the same legal effect as a lawfully issued paper attestation and is recognised in all Member States. | eIDAS Art. 45b [3] |
| B2B-5 | Attributes such as company data and powers to represent natural or legal persons are verified against authentic sources. | eIDAS Art. 45e, Annex VI [3] |
| B2B-6 | Know-your-business and supplier onboarding combine company identity, ownership and control, beneficial owners and representatives from several registers. Ownership and control form multi-level structures with shared and, in practice, cross-held nodes. | **[A]** domain practice; structural point formalised in 02 (R-C) |

Consequence: B2B evidence is relational (operator–representative–mandate–register entry) and comes from several issuers.

### 3.2 Digital twins

A digital twin is a maintained digital representation of an asset over its life. In European industry the Asset Administration Shell (AAS) is the reference model; its metamodel specification defines mappings to XML, JSON and RDF [21].

| ID | Requirement | Source |
|---|---|---|
| DT-1 | Twin content is structured as linked submodels that reference concept definitions (semantic IDs, e.g. ECLASS or IEC CDD). | AAS Part 1 [21] |
| DT-2 | An RDF serialisation exists, so twin data can join a graph without loss. | AAS Part 1, RDF mapping [21] |
| DT-3 | Twin data comes from several parties over the asset's life (manufacturer, integrator, operator, maintainer, recycler). Each contribution needs its own source and version. | **[A]** follows from DT-1 and multi-party lifecycle; cf. DPP-4 |
| DT-4 | Relations are first-class: part-of, made-from, installed-in, maintained-by. | AAS Part 1 (relationship elements) [21] |

### 3.3 Machine-to-machine (M2M)

| ID | Requirement | Source |
|---|---|---|
| M2M-1 | Devices act for an accountable operator; the binding device → operator must be verifiable. | Reference requirement term 6; CRA requirements on manufacturers of products with digital elements [25] **[A] for the binding as such** |
| M2M-2 | Exchanges are automated, often with low latency and high message rates; verification cost per message matters. | **[A]** operational property; quantified in 02 §6 and 03 |
| M2M-3 | Machine data is often confidential but must be checkable (e.g. against thresholds). | Reference tier T3 (Section 6) **[A]** |
| M2M-4 | Exchanged data must be interpretable without bilateral agreements on field names. | Reference requirement term 5; data-space practice, e.g. Catena-X wallet and credential requirements [27] |

### 3.4 Digital Product Passports (DPP)

| ID | Requirement | Source |
|---|---|---|
| DPP-1 | Product groups receive a DPP under ESPR delegated acts; data is held decentrally by economic operators or service providers, with a central registry of identifiers and links. | ESPR [17]; DPP registry implementing regulation [19] |
| DPP-2 | The battery passport is the first mandatory passport; it covers, among other data, carbon footprint, recycled content and due-diligence information. | Battery Regulation, Art. 77 and Annex XIII [18] |
| DPP-3 | The Commission's DPP registry technical package of 30 October 2026 places a semantic layer on W3C standards (RDF, JSON-LD, SKOS, SHACL, OWL); JSON remains the mandatory registration format. | Commission DPP resources [19]; summary in [32b] |
| DPP-4 | Passport data comes from several actors in the supply chain (supplier, manufacturer, recycler, testing body, register). Each statement needs an identifiable source. | ESPR [17]; Battery Regulation due-diligence and recycled-content provisions [18] |
| DPP-5 | Data must remain available and checkable for the product's life, which can span decades. | ESPR [17] **[A] for "decades" as typical range** |
| DPP-6 | International trade frameworks issue passports, conformity credentials and traceability events as W3C Verifiable Credentials. | UN Transparency Protocol [20] |
| DPP-7 | Traceability events are already standardised with a JSON-LD binding. | GS1 EPCIS 2.0 [37] |

### 3.5 Agent-to-agent (A2A)

Software agents increasingly negotiate, order and exchange data on behalf of organisations; open protocols for agent–tool and agent–agent communication exist [35].

| ID | Requirement | Source |
|---|---|---|
| A2A-1 | Every agent action traces to an accountable natural or legal person through a mandate and, where needed, a sub-delegation with bounded scope. | EBW mandates [1]; reference requirement term 6 **[A] for sub-delegation to agents, which the EBW proposal does not yet provide** |
| A2A-2 | The receiving party checks each requested operation against the agent's current authority, outside the model. | Reference requirement term 3 **[A]** |
| A2A-3 | Agents act on facts they did not create. They need to know who stated a fact, in which version and with which meaning. | Reference requirement terms 2, 5 **[A]** |
| A2A-4 | Facts arrive in large numbers and are merged before use (retrieval, planning). | **[A]**; quantified in 03 |

### 3.6 Safe AI

| ID | Requirement | Source |
|---|---|---|
| SAI-1 | High-risk AI systems need data governance for training, validation and testing data. | AI Act Art. 10 [22] |
| SAI-2 | High-risk AI systems need automatic record-keeping (logging) over their lifetime. | AI Act Art. 12 [22] |
| SAI-3 | A non-deterministic component should not decide safety-relevant actions alone; a simple, verified component bounds its behaviour (runtime assurance, "simplex" pattern). | Sha 2001 [33] |
| SAI-4 | The knowledge a safety monitor applies (rules, limits, requirements) must be authentic, of fixed meaning and versioned; otherwise the safety argument does not hold. | **[A]** follows from SAI-3; formalised in 02 (T3) |
| SAI-5 | Software, including AI, is a product under the new product liability regime; disclosure of evidence and presumptions shift the burden of proof. | Product Liability Directive [24] |

### 3.7 Industrial AI

| ID | Requirement | Source |
|---|---|---|
| IAI-1 | Industrial AI combines data from machines, products, suppliers and processes across company boundaries. | **[A]** domain practice; cf. DT, DPP |
| IAI-2 | Models, data sets and agents are virtual products that need passports of their own: version, provenance, evaluation evidence. | **[A]**; AI Act Art. 10–12 as the regulatory driver [22] |
| IAI-3 | Products with digital elements carry cybersecurity obligations over their support period, including vulnerability handling. | CRA [25] |
| IAI-4 | AI management systems require documented, traceable processes. | ISO/IEC 42001:2023 [36] |

### 3.8 Physical AI

| ID | Requirement | Source |
|---|---|---|
| PAI-1 | From 20 January 2027 the Machinery Regulation applies; its scope covers safety components with fully or partially self-evolving behaviour using machine learning. | Machinery Regulation 2023/1230 [23] |
| PAI-2 | The robot or machine identity, firmware and model versions, and the operator's identity must be bound to each other. | **[A]**; cf. M2M-1, CRA [25] |
| PAI-3 | Safety decisions run within tight latency budgets; evidence must be pre-verified and checkable at the point of use. | **[A]**; quantified in 03 (UC2) |
| PAI-4 | After an incident, it must be possible to reconstruct which facts, in which version, under whose authority, led to an action. | AI Act Art. 12 [22]; PLD [24] |

### 3.9 Cross-border trade: global interoperability of identifiers and credentials

Every domain above ends at the EU border: batteries, steel and electronics are made in global supply chains, and evidence about them is issued in other jurisdictions. The EBW therefore has to accept, and be accepted by, what the main trading partners use.

| ID | Requirement | Source |
|---|---|---|
| GI-1 | Evidence issued outside the EU (supplier declarations, test reports, origin, due diligence) must be verifiable in the EU, and EU evidence abroad, without conversion by an intermediary. | Reference requirement term 7; **[A]** conversion breaks issuer attribution (02, §7.4) |
| GI-2 | Identifiers of organisations, products and sites must be resolvable across jurisdictions without a central registry operated by one of them. | Reference requirement terms 4, 7; W3C DID Core [45] |
| GI-3 | The data model and identifier scheme should be those that trading partners' agencies and the UN trade-facilitation body already use or test. | **[A]** follows from GI-1; evidence below |
| GI-4 | Trust anchors stay jurisdictional: each relying party decides which foreign issuers and anchors it accepts. eIDAS provides for recognition of third-country trust services through international agreements. | eIDAS Art. 14 [3] **[A: recognition route to be confirmed for attestations of attributes]** |

**What the main jurisdictions use (public sources, status 7 November 2026).**

| Jurisdiction | Identifier and credential work | Data model and proof | Status | Source |
|---|---|---|---|---|
| EU, qualified tier and wallets | EUID, LEI optional for legal-person data; SD-JWT VC and ISO mdoc | Attribute sets; proof over bytes | Binding (CIR 2026/1731, 2026/1735) | [4][5] |
| EU, product and trade data | DPP registry semantic layer on RDF/JSON-LD; Catena-X W3C VCs | RDF/JSON-LD | Registry live; package of 30 Oct 2026 | [19][27] |
| UN/CEFACT (UNECE Rec. 49, UNTP) | did:web; did:webvh where auditability is required | W3C VCDM 2.0 in compacted JSON-LD; enveloping JOSE proof (`vc+jwt`) | Rec. 49 adopted July 2025; UNTP 1.0 not yet released | [20][47] |
| United States, DHS S&T | W3C DIDs, "bring your own DID" for USCIS | Profile (work in progress, 2022): compacted JSON-LD and Data Integrity proofs; multi-vendor plugfests on JSON-LD, linked-data signatures and DID resolution since 2020 | Programme funding and profile; digital immigration credentials piloted | [48][49][50] |
| United States, CBP (trade) | DIDs and VCs, described by CBP as the "global interoperability standards" it pursues | Steel and oil test, Aug 2023: over 1,000 VCs received; one-year crude-oil pipeline test announced June 2026 | Pilots, not filing obligations; the 2026 notice does not name W3C or JSON-LD | [51][52][53] |
| United States, NIST | SP 800-63C-4 (July 2025) names the W3C VC data model, next to SD-JWT and the ISO mdoc structure, as an example of attribute bundles; NIST IR 8480 (draft) distinguishes JSON-LD VCs that "follow the W3C Data Model" from SD-JWT VC, which "does not strictly follow" it, and notes that W3C flexibility can make interoperability harder; the NCCoE mDL draft (SP 1800-42A) claims alignment with VCDM 2.0 but builds on mdoc over OpenID4VP | Format-neutral guidance | Guidance, not a format mandate | [68][69][70] |
| United States, pharmaceutical supply chain (DSCSA) | Partnership for DSCSA Governance (PDG) blueprint, Chapter 6 v1.6 (15 July 2026): digital credentials are W3C VCs with DIDs as specified by the Open Credentialing Initiative (OCI); issuers, wallets and verification routers must conform to OCI criteria; the authorised-trading-partner credential is presented with every product verification request | OCI: VCDM 1.0 credentials with embedded linked-data proofs (graph domain, legacy suites); presentations as JWT; did:web and did:ethr | Industry governance under the DSCSA; credentialing optional alongside KYC; no FDA endorsement of a format found | [71][72] |
| United States, consumer identity | ISO/IEC 18013-5 mobile driving licences; California also issues a W3C VC format | mdoc dominant | State programmes; federal digital-identity section of EO 14144 removed in June 2025 | [16][54] |
| China, national identity | RealDID (Ministry of Public Security research institute with the Blockchain-based Service Network), real-name binding; ITU-T recommendations on DLT-based decentralised identity (X.1403, Y.3087, Y.4811, X.2310) | DLT-based; no primary source found that RealDID conforms to W3C DID Core | National deployment since Dec 2023 (secondary sources) | [55][56] |
| China, standards bodies and cross-border trade | CAICT, Ant Group and other Chinese organisations in the W3C DID Working Group; China–Singapore and China–Tanzania trade pilots using TradeTrust and W3C VCs | W3C VCs in cross-border pilots | Pilots | [57][58] |

**Reading.** No major jurisdiction has made W3C DIDs and VCs its national identity standard. But W3C DIDs and VCDM in JSON-LD are the common element across US trade pilots (DHS, CBP), the US pharmaceutical supply chain (DSCSA/OCI, in production use alongside non-credentialed alternatives), UN/CEFACT guidance (UNTP) and Chinese cross-border trade pilots, and NIST's identity guidelines name the W3C data model among admissible attribute-bundle formats. The DSCSA model is instructive: the credential carries an embedded proof over its statements, and the JWT envelope is used only for the short-lived presentation with each verification request. That is the division of labour 02 recommends (02, §5.3). Its credentials are still on VCDM 1.0 with legacy proof suites; migration to VCDM 2.0 with Data Integrity would align it with the profile proposed here. The EU's qualified tier currently admits neither of the two securing variants used there (Data Integrity in the DHS profile, VC-JOSE in UNTP). The securing mechanism differs between them; the data model (VCDM 2.0, JSON-LD) and the identifier scheme (DIDs, IRIs) are shared. GI-3 therefore points to the data model and identifiers first; 02 (L2) explains why, for evidence graphs, the graph-domain proof is preferable to an enveloping one.

## 4. Cross-domain properties

Seven properties recur. They are the inputs to the formal model in 02 (where they become R-G, R-I, R-O, R-M, R-P, R-C, R-A).

| Property | Short name in 02 | Definition |
|---|---|---|
| P1 Relational, multi-subject | R-G | Facts relate several subjects (product, operator, representative, agent, register entry, requirement). |
| P2 Identity across issuers | R-I | Facts from different issuers about the same subject must be recognisable as such without bilateral agreement. |
| P3 Open-world composition | R-O | Facts from independent issuers can be combined in any order; adding facts never invalidates the meaning of earlier ones. |
| P4 Shared meaning | R-M | Each attribute and relation has a meaning independent of who uses it; no silent name collisions. |
| P5 Per-fact provenance, version, status | R-P | Each fact traces to its source, its version and its current status, also after it has been combined with others. |
| P6 Shared and cyclic structure | R-C | The same node can be reached by several paths, and cycles occur (ownership, supply networks, delegation). |
| P7 Authority and assurance | R-A | Facts that carry legal or safety consequences come from issuers whose authority is itself attested, at a level the relying party's policy requires. |

Two operational properties are not structural but decide feasibility:

| Property | Definition |
|---|---|
| P8 Cost at scale | Verification work per consumed fact, latency at the point of use, throughput for mass data. |
| P9 Longevity | Facts remain verifiable and interpretable for the life of the product or system. |
| P10 Jurisdictional interoperability | Facts and identifiers issued under one jurisdiction's trust framework can be verified under another's without conversion by an intermediary (GI-1 to GI-4). |

### 4.1 Domain × property matrix

● required by source · ◐ required by domain practice [A] · blank: not central

| Domain | P1 | P2 | P3 | P4 | P5 | P6 | P7 | P8 | P9 |
|---|---|---|---|---|---|---|---|---|---|
| B2B | ● B2B-1 | ● B2B-1 | ◐ | ◐ | ● B2B-5 | ◐ B2B-6 | ● B2B-4/5 | ◐ | ◐ |
| Digital twins | ● DT-4 | ◐ | ◐ | ● DT-1 | ◐ DT-3 | ● DT-4 | ◐ | ◐ | ◐ |
| M2M | ◐ | ◐ | ◐ | ● M2M-4 | ◐ | | ◐ M2M-1 | ● M2M-2 | |
| DPP | ● DPP-4 | ● DPP-1 | ◐ | ● DPP-3 | ● DPP-4 | ◐ | ◐ | ◐ | ● DPP-5 |
| A2A | ◐ | ◐ | ◐ A2A-4 | ● A2A-3 | ● A2A-3 | ◐ | ● A2A-1 | ● A2A-4 | |
| Safe AI | ◐ | ◐ | ◐ | ● SAI-4 | ● SAI-1/2 | | ● SAI-4 | ● SAI-3 | ● SAI-2 |
| Industrial AI | ● IAI-1 | ◐ | ◐ | ◐ | ● IAI-2 | ◐ | ◐ | ◐ | ● IAI-3 |
| Physical AI | ◐ | ◐ | | ◐ | ● PAI-4 | | ● PAI-2 | ● PAI-3 | ● PAI-4 |

Reading: P1, P4, P5 and P7 are required in every domain. P2, P3 and P6 follow wherever facts from several issuers are combined, which is the normal case in B2B, DPP and A2A.

## 5. Derivation: the common core is a verifiable evidence graph

The argument in prose (formal version: 02, Theorem T1):

1. **Relations are facts.** P1 says the facts relate subjects. Any relation, including one with more than two participants, can be written as a set of binary statements (subject, predicate, object) by introducing a node for the relation itself.
2. **Subjects need global identifiers.** P2 says facts about the same subject from different issuers must be recognisable as such. Local names ("item 1") collide. Without coordination, only globally scoped identifiers (URIs, including DIDs) avoid collisions.
3. **Predicates need global meaning.** P4 says a term means the same for every user. Two issuers that both write `status` but mean different things cannot be merged safely unless the name is scoped, which again requires global names (vocabulary IRIs).
4. **Combination must be order-independent and monotone.** P3 says facts can be combined in any order and adding facts never invalidates earlier meaning. Set union of statements has these properties; overwriting fields of a JSON object does not.
5. **Shared nodes and cycles exclude trees.** P6 says a node can be reached by several paths and cycles occur. A tree has exactly one path to each node, so it must duplicate shared nodes and cannot express cycles without identifiers. Once identifiers are added, the tree is a serialisation of a graph.
6. Steps 1–5 give a set of statements with globally identified subjects, predicates and objects, combined by union: the abstract syntax of RDF [13]. JSON-LD is its JSON serialisation [12].
7. **Verifiability must survive combination.** P5 says every fact keeps its source, version and status after it has been combined with others. This is a requirement on the proof, not on the data model. 02 shows that this holds when the proof is computed over the canonical statements (W3C Data Integrity with RDF Dataset Canonicalization [10][11]). It does not hold when the proof covers the bytes of an envelope (SD-JWT [14], or any JWS/COSE envelope) (02, Lemma L2).
8. **Assurance must reach the trust edges.** P7 says the relying party's policy requires attested authority for consequential facts. 02 (Theorem T3) shows that the assurance of a conclusion is bounded by the weakest fact that can change it on its own, and that trust edges (identity, register extract, mandate, accreditation) can change every conclusion that depends on them. If graph-native credentials cannot be qualified, the graph cannot reach the qualified level.

Result: the domains need **verifiable evidence graphs**: RDF statements whose proofs are bound to the statements, linked by identifier and digest, with QEAA available for the trust edges.

### 5.1 External evidence: the web already runs on this data model

The graph model derived above is not new to industry or to AI. It is the web's metadata layer.

| Fact | Source |
|---|---|
| schema.org was launched in June 2011 by Google, Microsoft (Bing) and Yahoo, with Yandex joining the same year, as a shared vocabulary for structured data in web pages. | [59] |
| Google recommends JSON-LD for structured data; Microdata and RDFa are also accepted. | [60] |
| Structured data appears on about half of crawled pages: 50% of pages in the HTTP Archive Web Almanac 2025; about 52% of 2.39 billion parsed pages and 16.5 million domains in the Web Data Commons extraction of the October 2024 Common Crawl, yielding about 74 billion statements (triples). | [61][62] |
| JSON-LD is the most used syntax for it: 43% of home pages in the Web Almanac 2025 (Microdata 16–19%, RDFa 1–2%). | [61] |
| Search engines build knowledge graphs of entities and their relations. Google reported over 500 billion facts about five billion entities in May 2020, and stated in March 2025 that its LLM-based AI Mode draws on the Knowledge Graph. | [63][64] |
| Wikidata is a public RDF graph of about 124 million items, queryable with SPARQL; its query service was split in 2025 because of size. | [65] |

What follows and what does not:
1. **The data model and syntax scale.** Statements in JSON-LD, with global identifiers and a shared vocabulary, are produced by millions of sites and consumed by search systems that answer queries at internet scale. This supports P8 (cost at scale) for the data-model part: graph semantics are not what makes evidence graphs expensive. Search engines publish no latency or throughput figures for their knowledge-graph lookups, so no performance number is claimed here.
2. **AI systems already consume knowledge graphs.** LLM-based search uses a knowledge graph as one of its sources [64]. Google also states that no special schema.org markup is needed to appear in its AI features [66], so this paper does not claim that publishing JSON-LD causes inclusion in AI answers.
3. **The web's graph is unverified.** schema.org statements are self-asserted by site owners: they have no issuer proof, no version and no status. In the levels of 02 (§2.5) they sit at $\bot$ or $U$. By 02, Theorem T3, any automated decision grounded in them has at most that assurance. This is the gap the reference requirement addresses.
4. **Adding a proof keeps the format.** A W3C VC with a Data Integrity proof is a JSON-LD document whose proof is embedded in it, so it can be published and processed where JSON-LD is published and processed today. An enveloping proof (JWS, SD-JWT) turns the statements into an opaque string inside an envelope (02, §5.1). Figure 1 shows the three levels.

![Figure 1. One data model, three levels of assurance](fig-1-web-kg-to-evidence-graph.svg)

What this derivation does not claim:
- It does not claim that every fact must be signed (Section 6).
- It does not claim that SD-JWT VC or ISO mdoc are unsuitable for presenting personal or organisational identity from a wallet. For small, stable attribute sets with privacy requirements they are well suited, and selective disclosure at claim level is cheaper there (02, §6.5).
- It does not claim that RDF is the only conceivable graph model. It claims that the requirements imply a graph with global identifiers and order-independent composition, and that RDF is the standardised, open-world instance with an existing industrial ecosystem (AAS [21], EPCIS [37], UNTP [20], the DPP registry semantic layer [19]).

## 6. Not everything needs verification: tiers

| Tier | Applies to | Mechanism | Level in 02 |
|---|---|---|---|
| T0 Internal / derived | Facts inside one trust domain; analytics, aggregates, inferences | Own governance; provenance link (W3C PROV-O [29]) to verified inputs | U |
| T1 Source-attested | Facts that cross a trust boundary | Issuer signature, version, status | E (EAA or other non-qualified attestation) |
| T2 Qualified / authoritative | Facts with legal effect or from authentic sources | QEAA, PuB-EAA, qualified seal [3] | Q |
| T3 Confidential-verifiable | Facts that may be checked but not disclosed | Selective disclosure, zero-knowledge proofs, hardware attestation | orthogonal disclosure mode at level E or Q |

Decision rule **[A]**: a fact is at least T1 if it crosses a trust boundary, feeds an automated decision, has legal or liability consequences, invites falsification, or must remain checkable for years. The relying party's trust policy decides which issuers, tiers and ages it accepts.

## 7. Where the regulatory baseline stands

| Fact | Source |
|---|---|
| Recital 4 of the EBW proposal applies the eIDAS technical specifications, their implementing regulations and the architecture and reference framework to the EBW. | [1] |
| CIR (EU) 2026/1731 references clauses 2–6 of ETSI TS 119 472-1 V1.2.1 (IETF SD-JWT VC and ISO mdoc profiles), not the W3C VCDM profile in clause 7. Recital 1 states that wallets should also support W3C VCDM "when the new profiles on the W3C VCDM format are available". | [4], [6] |
| CIR (EU) 2026/1735 requires QEAA and PuB-EAA providers to issue in a format listed in that annex. | [5] |
| ETSI TS 119 472-2 builds on OpenID4VC HAIP 1.0, final since 24 December 2025, which profiles SD-JWT VC and mdoc only. | [6b], [8] |
| IETF SD-JWT VC is a distinct data model from W3C VCDM: it does not use `@context`; type semantics come from the `vct` claim and type metadata. Its media type changed from `vc+sd-jwt` to `dc+sd-jwt` in draft -08 (December 2024). | [15] |
| ETSI TR 119 060 (EBW standardisation gap analysis) is announced for publication on 28 November 2026. Its public work item covers gaps including chained attestations, access control and logging. Clause numbers will be cited from the published text. | [7] |

So today the qualified tier admits only formats whose data model is an attribute set about one subject (02, §2.6). The W3C VCDM profile that would carry graphs into the qualified tier is not yet referenced.

## References

[1] European Commission, Proposal for a Regulation on European Business Wallets, COM(2025) 838, procedure 2025/0358(COD). https://eur-lex.europa.eu/legal-content/EN/TXT/?uri=CELEX:52025PC0838
[2] Council of the EU, European Business Wallets: Council adopts negotiating position, 9 June 2026. https://www.consilium.europa.eu/en/press/press-releases/2026/06/09/european-business-wallets-council-adopts-negotiating-position/
[3] Regulation (EU) No 910/2014 (eIDAS) as amended by Regulation (EU) 2024/1183, in particular Art. 45b, 45e and Annex VI. https://eur-lex.europa.eu/eli/reg/2024/1183/oj
[4] Commission Implementing Regulation (EU) 2026/1731 of 15 July 2026. https://eur-lex.europa.eu/eli/reg_impl/2026/1731/oj
[5] Commission Implementing Regulation (EU) 2026/1735 of 15 July 2026. https://eur-lex.europa.eu/eli/reg_impl/2026/1735/oj
[6] ETSI TS 119 472-1 V1.2.1 (2026-02). https://www.etsi.org/deliver/etsi_ts/119400_119499/11947201/01.02.01_60/ts_11947201v010201p.pdf
[6b] ETSI TS 119 472-2 (presentation profiles). https://www.etsi.org/standards (exact version to be confirmed)
[7] ETSI work item DTR/ESI-TR 119 060, Standardization Gap Analysis for the EBW Ecosystem. https://portal.etsi.org/webapp/WorkProgram/Report_WorkItem.asp?WKI_ID=78177
[8] OpenID Foundation, OpenID4VC High Assurance Interoperability Profile 1.0, final, 24 December 2025. https://openid.net/specs/ (exact URL to be confirmed)
[9] W3C, Verifiable Credentials Data Model v2.0, Recommendation, 15 May 2025. https://www.w3.org/TR/vc-data-model-2.0/
[10] W3C, Verifiable Credential Data Integrity 1.0, Recommendation, 15 May 2025. https://www.w3.org/TR/vc-data-integrity/
[11] W3C, RDF Dataset Canonicalization (RDFC-1.0), Recommendation, 21 May 2024. https://www.w3.org/TR/rdf-canon/
[12] W3C, JSON-LD 1.1, Recommendation, 16 July 2020. https://www.w3.org/TR/json-ld11/
[13] W3C, RDF 1.1 Concepts and Abstract Syntax, Recommendation, 25 February 2014. https://www.w3.org/TR/rdf11-concepts/
[14] IETF RFC 9901, Selective Disclosure for JSON Web Tokens (SD-JWT), November 2025. https://www.rfc-editor.org/rfc/rfc9901
[15] IETF draft-ietf-oauth-sd-jwt-vc (SD-JWT-based Verifiable Credentials); media type `dc+sd-jwt` from draft -08. https://datatracker.ietf.org/doc/draft-ietf-oauth-sd-jwt-vc/
[16] ISO/IEC 18013-5:2021, Mobile driving licence (mDL) application.
[17] Regulation (EU) 2024/1781 (Ecodesign for Sustainable Products Regulation, ESPR). https://eur-lex.europa.eu/eli/reg/2024/1781/oj/eng
[18] Regulation (EU) 2023/1542 (Batteries Regulation). https://eur-lex.europa.eu/eli/reg/2023/1542/oj/eng
[19] Commission Implementing Regulation (EU) 2026/1778 (DPP registry), https://eur-lex.europa.eu/eli/reg_impl/2026/1778/oj/eng ; European Commission, DPP resources and documentation (technical package of 30 October 2026), https://single-market-economy.ec.europa.eu/single-market/digital-product-passport/resources-documentation_en
[20] UN/CEFACT, UN Transparency Protocol (UNTP). https://spec-untp-fbb45f.opensource.unicc.org/
[21] IDTA, Specification of the Asset Administration Shell, Part 1: Metamodel (IDTA-01001), with XML, JSON and RDF mappings. https://industrialdigitaltwin.org/en/content-hub/aasspecifications/specification-of-the-asset-administration-shell-part-1-metamodel-idta-number-01001
[22] Regulation (EU) 2024/1689 (Artificial Intelligence Act), Art. 10, 12. https://eur-lex.europa.eu/eli/reg/2024/1689/oj
[23] Regulation (EU) 2023/1230 (Machinery Regulation). https://eur-lex.europa.eu/eli/reg/2023/1230/oj
[24] Directive (EU) 2024/2853 (Product Liability Directive). https://eur-lex.europa.eu/eli/dir/2024/2853/oj
[25] Regulation (EU) 2024/2847 (Cyber Resilience Act). https://eur-lex.europa.eu/eli/reg/2024/2847/oj
[27] Catena-X, CX-0149 Wallet Requirements v2.1.0. https://github.com/catenax-eV/catenax-ev.github.io/blob/main/docs/standards/CX-0149-WalletRequirements/CX-0149-WalletRequirements.md
[28] The Semantic Supply Chain: A Comparative Risk Analysis of Credential Meaning Distribution in W3C VCDM, SD-JWT VC, and ISO mdoc, working paper, 7 May 2026. https://hackmd.io/@KsjE2xL6Q_CAsVkYWt58iA/S17wr3tR-e
[29] W3C, PROV-O: The PROV Ontology, Recommendation, 30 April 2013. https://www.w3.org/TR/prov-o/
[30] W3C, ODRL Information Model 2.2, Recommendation, 15 February 2018. https://www.w3.org/TR/odrl-model/
[31] W3C, Shapes Constraint Language (SHACL), Recommendation, 20 July 2017. https://www.w3.org/TR/shacl/
[32a] Spherity Research, EBW roadmap. https://spherity.github.io/spherity-research/ebw-roadmap.html
[32b] Spherity Research, EU DPP Registry and W3C standards. https://spherity.github.io/spherity-research/eu-dpp-registry-w3c-dpp5.html
[33] L. Sha, "Using simplicity to control complexity", IEEE Software 18(4), 2001, 20–28.
[35] Model Context Protocol, https://modelcontextprotocol.io/ ; Agent2Agent (A2A) Protocol, https://a2a-protocol.org/
[36] ISO/IEC 42001:2023, AI management system; IEC 62443 series, industrial communication networks – security.
[37] GS1, EPCIS and CBV 2.0 (2022), including a JSON/JSON-LD binding. https://ref.gs1.org/standards/epcis/
[45] W3C, Decentralized Identifiers (DIDs) v1.0, Recommendation, 19 July 2022, https://www.w3.org/TR/did-core/ ; DIDs v1.1, Candidate Recommendation, 5 March 2026, https://www.w3.org/TR/did-1.1/ ; DID Resolution, Candidate Recommendation Draft, 3 November 2026, https://www.w3.org/TR/did-resolution/
[46] did:web method, W3C Credentials Community Group draft, https://w3c-ccg.github.io/did-method-web/ ; did:webvh v1.0, Decentralized Identity Foundation, 7 August 2025, https://blog.identity.foundation/dif-celebrates-v1-0-release-of-did-webvh/
[47] UNECE, Recommendation No. 49 "Transparency at Scale", adopted July 2025, https://unece.org/sustainable-development/press/new-un-policy-recommendation-foster-transparency-and-accountability ; UNTP verifiable credentials profile (work in progress), https://spec-untp-fbb45f.opensource.unicc.org/docs/specification/VerifiableCredentials
[48] DHS S&T SVIP, report on Plug-Fest 1 (May 2020), W3C CCG mailing list, 4 March 2021. https://lists.w3.org/Archives/Public/public-credentials/2021Mar/0022.html
[49] DHS, Implementation Profile of W3C Verifiable Credentials and Decentralized Identifiers (work in progress), 29 September 2022. https://lists.w3.org/Archives/Public/public-credentials/2022Sep/att-0253/DHS.W3C.VC-DID.Implemenation.Profile-20220929-SHARE.pdf
[50] DHS S&T, feature article on digital credentials with USCIS, 9 July 2024. https://www.dhs.gov/science-and-technology/news/2024/07/09/feature-article-question-who-you-are
[51] CBP, Global Interoperability Standards test review (steel and oil, 22–30 August 2023), May 2024. https://cbp.gov/sites/default/files/2024-05/360%20review%20Summary%20GIS%20Part%201%20%281%29_508.pdf
[52] CBP, ACE 2.0 issue paper, December 2024. https://cbp.gov/sites/default/files/2024-12/ngf_ace_2.0_issue_paper_-_dec_2024.pdf
[53] Federal Register, CBP NCAP Pipeline Global Interoperability Standards Test, 2 June 2026. https://www.federalregister.gov/d/2026-10979
[54] Congressional Research Service, Insight IN12570 on EO 14306, 18 June 2025, https://www.everycrsreport.com/reports/IN12570.html ; OpenID Foundation on the California mDL hackathons, 16 December 2024, https://openid.net/driving-innovation-and-adoption-reflections-california-mdl-hackathons/
[55] South China Morning Post, report on the RealDID launch, 12 December 2023 (secondary source). https://scmp.com/tech/policy/article/3245028/blockchain-managed-ids-arrive-china-new-government-backed-scheme-aiming-reduce-data-leaks
[56] ITU-T X.1403 (09/2020), https://www.itu.int/rec/T-REC-X.1403-202009-I/en ; Y.3087 (04/2025), https://www.itu.int/ITU-T/workprog/wp_item.aspx?isn=21507 ; Y.4811 (11/2021), https://www.itu.int/ITU-T/workprog/wp_item.aspx?isn=16413 ; X.2310 (03/2026), https://www.itu.int/dms_pubrec/itu-t/rec/x/T-REC-X.2310-202603-I!!SUM-HTM-E.htm
[57] W3C DID Working Group participants (page as of 7 November 2026). https://www.w3.org/groups/wg/did/participants
[58] ICC Digital Standards Initiative, China–Tanzania trade digitalisation pilot (updated 2 December 2025), https://www.digitalizetrade.org/node/283 ; TradeTrust newsletter, September 2025, https://isomer-user-content.by.gov.sg/271/8b69edfb-5035-47e4-9fef-d0c3ef18d14b/Tradetrust_Newsletter_September_2025.pdf
[59] schema.org, About, https://schema.org/docs/about.html ; Google Search Central blog, Introducing schema.org, 2 June 2011, https://developers.google.com/search/blog/2011/06/introducing-schemaorg-search-engines
[60] Google Search Central, Introduction to structured data markup. https://developers.google.com/search/docs/appearance/structured-data/intro-structured-data
[61] HTTP Archive, Web Almanac 2025, SEO chapter, 15 January 2026. https://almanac.httparchive.org/en/2025/seo
[62] Web Data Commons, schema.org extraction from Common Crawl October 2024, released 10 January 2025. https://webdatacommons.org/structureddata/
[63] Google, "A reintroduction to our Knowledge Graph and knowledge panels", 20 May 2020. https://blog.google/products/search/about-knowledge-graph-and-knowledge-panels/
[64] Google, "Expanding AI Overviews and introducing AI Mode", 5 March 2025. https://blog.google/products/search/ai-mode-search/
[65] Wikidata statistics (as of 7 November 2026), https://www.wikidata.org/wiki/Wikidata:Statistics
[66] Google Search Central, AI features and your website. https://developers.google.com/search/docs/appearance/ai-features
[68] NIST SP 800-63C-4, Digital Identity Guidelines: Federation and Assertions, July 2025, §3.12.1 (reference [VC] is VCDM 1.1). https://nvlpubs.nist.gov/nistpubs/SpecialPublications/NIST.SP.800-63C-4.pdf
[69] NIST IR 8480 (initial public draft), Attribute Validation Services for Identity Management, October 2024, §7.3.3. https://nvlpubs.nist.gov/nistpubs/ir/2024/NIST.IR.8480.ipd.pdf
[70] NIST SP 1800-42A (initial public draft), Digital Identities – Mobile Driver's License, March 2026. https://www.nccoe.nist.gov/ (exact PDF URL in research notes)
[71] Partnership for DSCSA Governance, Foundational Blueprint for 2023 Interoperability, Chapter 6: DSCSA Credentialing and User Authentication Functional Design, v1.6, 15 July 2026 (v1.0: 1 March 2023). https://dscsagovernance.org/ **[exact PDF URL to be confirmed]**
[72] Open Credentialing Initiative, Digital Wallet Conformance Criteria v3.4.1, 12 August 2024, https://open-credentialing-initiative.github.io/Digital-Wallet-Conformance-Criteria/latest/ ; Credential Schema specification, https://open-credentialing-initiative.github.io/schemas/specification/latest
