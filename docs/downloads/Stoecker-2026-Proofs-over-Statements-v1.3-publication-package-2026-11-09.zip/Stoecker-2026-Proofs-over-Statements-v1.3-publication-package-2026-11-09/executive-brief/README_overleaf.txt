SPHERITY RESEARCH PAPER — LATEX SOURCE
Prepared 9 November 2026

Main file: main.tex
Compiler: pdfLaTeX (TeX Live 2026 used for production).
Build: latexmk -pdf -interaction=nonstopmode -halt-on-error main.tex
Alternatively run pdflatex three times to settle the references and contents.
Overleaf: upload this folder's contents and select main.tex and pdfLaTeX.

Included:
  main.pdf              Compiled document
  assets/               Official CC BY 4.0 badge
  figures/              Vector PDF figures; editable SVGs in figures/source/
  source/original.docx  Unchanged reviewed Word manuscript
  source/extracted.md   Word extraction for traceability, not the final layout
  source/extracted.json Structured Word extraction
  source/media/         Original extracted Word images
  editorial-review.txt Editorial review and evidence limitations
  conversion-qa.txt    LaTeX production checks and documented changes
  credential-review.txt Expert review of all three JSON-LD fragments
  logic-review.txt      Detailed argument, formula and consistency review
  source/logic-review/  Exact editorial changes and arithmetic audit evidence
  source/credential-review/ Executed semantic/disclosure checks and test evidence
  examples/             Complete signed credentials, exact nested token, public
                        verification scripts, results and pinned contexts

Copyright: Carsten Stöcker, Spherity GmbH, 2026.
Except where otherwise noted, the work is licensed under CC BY 4.0.
https://creativecommons.org/licenses/by/4.0/

The Word source is retained unchanged. The final LaTeX includes requested
production edits: displayed JSON examples, removal of proof-ending black
squares, and placement/reference of Figure 1 in the executive brief.
The final LaTeX also corrects the P1 vct context mapping and clarifies the
semantic fragments' scope. See credential-review.txt for the exact changes.
No benchmark implementation or benchmark reproduction is included. The local
semantic/disclosure checks are separate from the paper's performance benchmark.
Both documents now include complete signed plain and nested credential examples.
See examples/README.txt for public-only cryptographic reproduction and scope.
The final argument review clarifies the common graph-profile recommendation,
envelope-only versus dual-proof nesting, alternative trust paths, schema-policy
consistency and empirical limitations. See logic-review.txt for findings.
The paper-level CC BY licence does not assign a software licence to verification
scripts; dependency and archived-context notices are retained in examples/.
