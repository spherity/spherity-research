# Argument clarity and cross-document audit

Reviewed 9 November 2026. Scope: full paper and executive brief, including the argument, use cases, conclusion, limitations and complete-example appendices. This is an editorial and logical consistency audit, not an independent reproduction of the benchmark.

## Findings supplied for correction

1. **P1: Attribution versus content fraud.** Full paper section 6.2, former main.tex line 753, described duty evasion and counterfeit goods collectively as attribution attacks. This conflicted with the subsequent analysis of genuinely issued false content. Separate impersonation/forged submissions from false classification/conformity; retain corroboration, consistency checking and examination as distinct controls. The rebuilt PDF page 38 now makes this distinction clearly.
2. **P1: B1 versus dual-proof nesting.** Table labels formerly said broadly “JSON-LD inside SD-JWT,” although the properties described the envelope-only B1 benchmark. The complete nested example also retains an inner Data Integrity proof. Label the comparison as B1, and explicitly exclude the appendix dual-proof construction from its timing/proof-domain claims. Rebuilt paper pages 33–34 now distinguish these.
3. **P2: State the engineering preference explicitly.** The former conclusion centred on the eligibility necessary after choosing one profile. Lead instead with a common VCDM 2.0, JSON-LD, RDF-based Data Integrity profile as the preferred persistent evidence format for the specified retained/reverified graph workload. JSON-LD syntax alone is not the distinction. Add envelopes for defined purposes and retain appropriate alternatives. Rebuilt pages 48–49 state this clearly and preserve the scope limits.
4. **P2: Unsupported 1:5 estimate.** The brief must match the full paper’s disclosure that the author-provided estimate of 1 QEAA per 5 ordinary EAAs has no supplied supporting dataset or methodology. Preserve this ratio direction.
5. **P2: Mandatory dependencies and alternative paths.** Avoid claiming every conclusion with any dependency on a missing qualified link necessarily fails. Specify mandatory dependencies and policy-authorised alternatives. A common profile helps express and check requirements; it cannot repair missing assurance.
6. **P2: Benchmark availability.** Appendix B formerly described benchmark2/ and commands as though those files were supplied, whereas declarations disclose their absence. Introduce the unavailable archive explicitly and make commands conditional on obtaining it. Rebuilt page 50 now does so. Supplied examples/ remains a separate runnable cryptographic fixture.
7. **P3: Enumeration.** Brief section 2 formerly said “Three distinctions matter” but listed two. Change to “Two distinctions matter.”

## Suggested conclusion language

For industrial workflows that combine evidence from many issuers, preserve it across organisations and repeatedly verify it as graph data, we recommend a common W3C VCDM 2.0 profile expressed in JSON-LD and secured with an RDF-based Data Integrity suite as the persistent evidence format. This aligns the representation used for graph processing with the issuer-authenticated proof domain, provided that source snapshots, graph positions, proof configuration and interpretation rules remain recoverable. JSON-LD syntax alone does not provide these properties. A shared profile can reduce the number of format mappings and verification rules that implementations must govern, test and audit; that organisational saving was not measured by this paper.

Add an envelope when a defined presentation, disclosure or interoperability requirement justifies it. An envelope-only construction requires retained or reliably reconstructible signing inputs and a governed source-to-graph binding. A nested construction that preserves an inner graph proof can retain graph-native verification, but adds outer verification and binding obligations when the application relies on both layers. A presentation-only wrapper need not be checked on every subsequent use of independently verified inner evidence. Neither construction is inherently insecure. The reported performance advantage applies to the specified repeated-verification workload with refreshed mapping; it does not establish universal superiority over presentation formats or protected cached mappings.

To use this common profile for ordinary evidence and the qualified authority attestations required by policy, standards and issuance rules should make an appropriate graph-proof profile eligible alongside existing profiles. Eligibility does not qualify an issuer, make an assertion true or establish the safety of a decision. The receiving policy must still validate authority, scope, status and source bindings, and address both content substitutions and attacks on authority. Retain the separately qualified PQC/multiple-signatures paragraph.

## Arguments already aligned

- The abstract, analysis and limitations distinguish fresh-mapping measurements, envelope-only checks and separate presentation benchmarks.
- The complete appendix examples distinguish dual-proof nesting from B1 and do not assign B1 timings to the new construction.
- Qualified status is separated from signature validity and downstream truth.
- PQC is separate from credential-format nesting; multiple proofs do not by themselves establish a secure hybrid design.
- Scenario volumes and latency budgets are disclosed; prototype timings are not presented as certified deadlines or production capacity.

## Final visual QA: full paper pages 33–64

All assigned pages were inspected through contact-09.png through contact-16.png. Pages 42, 53, 54 and 55 were additionally inspected at full-page resolution for tight table and code layout.

**Pass:** no clipping, overlaps, stray black squares, missing glyphs or broken figure/table placement observed in these pages. The changed conclusion, B1 comparison headings, customs paragraph and benchmark-availability notice render correctly. JSON and credential tokens are visibly formatted as code; long proof/key/token strings wrap inside their frames, and multipage listings preserve their content. Figures 6–8 and their captions appear coherent with the adjacent explanations. References remain inside the page boundaries.

Non-blocking layout observations: page 36 intentionally uses a landscape page for a short wide table and therefore has substantial whitespace; page 51 has substantial whitespace before Appendix C begins on a new page. Neither is a correctness or legibility defect.
