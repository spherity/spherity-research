"""Internal arithmetic audit; this does NOT reproduce the missing benchmark.

Inputs below are printed manuscript values, except explicitly constructed rounding
witnesses. Witnesses show that rounding can explain apparent discrepancies; they
are NOT recovered measurements and must never be cited as benchmark observations.
"""
from decimal import Decimal, ROUND_HALF_UP
from pathlib import Path
import json

D = lambda x: Decimal(str(x))

def rounded(value, places=0):
    return float(D(value).quantize(D(1).scaleb(-places), rounding=ROUND_HALF_UP))

out = {
    "scope": "Internal consistency of printed quantities only; no benchmark reproduction",
    "constructed_witness_warning": "Witness inputs are artificial, not recovered measurements",
}

table3 = [(17,107,704,92,597),(50,149,797,134,649),
          (146,282,1063,254,781),(374,563,1884,652,1321),
          (574,766,2760,1193,1994)]
out["table3"] = []
for n,a,b,bs,delta in table3:
    # Independent rounding of B, A and delta permits a one-unit discrepancy.
    assert abs((b-a)-delta) <= 1
    out["table3"].append({"quads":n,"difference_of_printed_values_us":b-a,
        "printed_delta_us":delta,"envelope_relative_to_A_percent":100*(bs/a-1),
        "compatible_with_independent_rounding":True})

out["146_quad_rates_per_second"] = {"A":1e6/282,"B":1e6/1063,"Bs":1e6/254,
    "A_quad_events":146e6/282,"B_fresh_quads":146e6/1063}
out["strict_integer_crossover"] = {"printed_root":4.24,"first_strictly_cheaper_R":5,
    "additional_checks_R":True,"ingestion_also_counts_one_verification_event":True}

# One jointly feasible witness for Table 3, all UC1 rows, and the printed 4.24 root.
# These are NOT benchmark data. They establish no contradiction in rounded values.
a1,b1,bs1 = map(D,[282,1062.9,254.3])
a0,b0 = map(D,[2645,1390])
aup,bup = map(D,[4923.6,1614.7])
out["UC1_rounding_witness_inputs_us_NOT_MEASUREMENTS"] = {
    "A1":float(a1),"B1":float(b1),"Bs1":float(bs1),
    "A0":float(a0),"B0":float(b0),"IA_plus_A0":float(aup),"IB_plus_B0":float(bup)}
expected = [(100000000,1,[145,74,52],[.51,.36],[10.0,8.4,5.6]),
            (100000000,3,[160,133,66],[.83,.41],[6.0,7.8,3.7]),
            (100000000,10,[215,340,115],[1.58,.54],[3.4,7.5,2.4]),
            (1000000000,10,[2151,3401,1155],[1.58,.54],[3.4,7.5,2.4])]
out["UC1_rounding_witness_results"] = []
for count,r,hours,ratios,quad_costs in expected:
    costs = [aup+r*a1,bup+r*b1,bup+r*bs1]
    calc_hours = [rounded(c*count/D(3600000000)) for c in costs]
    calc_ratios = [rounded(costs[1]/costs[0],2),rounded(costs[2]/costs[0],2)]
    calc_quads = [rounded((base+r*extra)/(146*(r+1)),1)
                  for base,extra in [(a0,a1),(b0,b1),(b0,bs1)]]
    assert calc_hours == hours, (count,r,calc_hours,hours)
    assert calc_ratios == ratios
    assert calc_quads == quad_costs
    out["UC1_rounding_witness_results"].append({"credentials":count,"R":r,
        "core_hours":calc_hours,"ratios":calc_ratios,"us_per_quad_event":calc_quads})
root = (aup-bup)/(b1-a1)
assert rounded(root,2)==4.24
assert rounded((a0-b0)/(b1-a1),1)==1.6
out["UC1_witness_crossover"] = float(root)
out["UC1_witness_cumulative_ms_at_crossover"] = float((aup+root*a1)/1000)

out["UC2_from_printed_values"] = {}
for name,initial,extra in [("A",16,149),("B",7,797),("Bs",7,134)]:
    additional_ms = D(8*3*extra)/1000
    hours = (D(initial)+additional_ms)*4000000/3600000
    out["UC2_from_printed_values"][name] = {
        "three_rechecks_ms_per_shipment":float(additional_ms),
        "million4_shipments_hours":float(hours),"rounded_hours":rounded(hours)}
assert [out["UC2_from_printed_values"][x]["rounded_hours"] for x in ["A","B","Bs"]]==[22,29,11]

out["UC3_direct_calculations"] = {
    "printed_speedups":[1.7/.51,9.2/2.6,8.4/3.1,50/14],
    "projected_A_seconds_from_printed_50000":3.1*4,
    "projected_B_seconds_from_printed_50000":14*4,
    "fresh_10000_ingestions_seconds":10000*.002}
out["UC3_rounding_witness_NOT_MEASUREMENTS"] = {
    "B_50000_single_worker_s":50.4,"B_50000_eight_workers_s":13.75,
    "rounded_single":rounded(50.4),"rounded_eight":rounded(13.75),
    "projection_to_200000":13.75*4,
    "rounded_speedup":rounded(D(50.4)/D(13.75),1)}

# Table 7 and Table 3 can share these unrounded medians.
medians = {"A":D(148.6),"B":D(797.2),"Bs":D(134)}
percentiles = {"A":D(178),"B":D(4150),"Bs":D(156)}
assert rounded(medians["B"]-medians["A"]) == 649
expected_t7 = {
  5: {"A":[.74,.89],"B":[4.0,21],"Bs":[.67,.78]},
  20:{"A":[3.0,3.6],"B":[16,83],"Bs":[2.7,3.1]},
  100:{"A":[15,18],"B":[80,415],"Bs":[13,16]}}
places = {
  5:{"A":[2,2],"B":[1,0],"Bs":[2,2]},
  20:{"A":[1,1],"B":[0,0],"Bs":[1,1]},
  100:{"A":[0,0],"B":[0,0],"Bs":[0,0]}}
out["UC3_table7_rounding_witness_NOT_MEASUREMENTS"] = {}
for f in [5,20,100]:
    vals={}
    for name in medians:
        vals[name]=[rounded(f*medians[name]/1000,places[f][name][0]),
                    rounded(f*percentiles[name]/1000,places[f][name][1])]
    assert vals==expected_t7[f],(f,vals)
    out["UC3_table7_rounding_witness_NOT_MEASUREMENTS"][f]=vals

production = Path(__file__).resolve().parents[2]
example_sets = [(document, production/document/"examples") for document in ["paper","brief"]]
if not all(folder.is_dir() for _, folder in example_sets):
    delivery = next(p for p in Path(__file__).resolve().parents if (p/"examples").is_dir())
    example_sets = [(delivery.name, delivery/"examples")]
for document, examples in example_sets:
    plain=json.loads((examples/"plain-vc.json").read_text(encoding="utf-8"))
    compact=json.dumps(plain,ensure_ascii=False,separators=(",",":")).encode("utf-8")
    nested=(examples/"nested.sd-jwt").read_bytes().rstrip(b"\r\n")
    assert len(compact)==797
    assert len(nested)==1534
    out[f"{document}_example_bytes"]={"plain_compact":len(compact),"nested":len(nested)}

Path(__file__).with_name("arithmetic-results.json").write_text(json.dumps(out,indent=2)+"\n",encoding="utf-8")
print("PASS: rounded-table consistency, UC1 witness, UC2 totals, UC3 witness, and example byte counts")
