**Why business wallet evidence graphs need a qualified W3C VCDM
profile**

**Executive brief for wallet, identity, legal and standardisation
decision-makers**

Dr. Carsten Stöcker, Spherity GmbH, Düsseldorf. AI assurance graph
edition, 9 November 2026. Based on the paper Proofs over Statements in
Verifiable Evidence Graphs for the European Business Wallet (reviewed
version 1.3, CC BY 4.0) \[1\].

![figure 1 wallet
workflows](media/media/47d2549afcb0da1e5de590e7940546cba292f006.png){width="6.299212598425197in"
height="4.0493777340332455in"}

**Figure 1.** Citizen presentation and retained business evidence. Green
relationships are EAA-backed; blue dashed relationships require QEAAs
under the decision policy. The proposed common graph stack preserves
issuer, scope, status and assurance level. Colour denotes supporting
attestations, not independently signed edges. The examples illustrate
workloads, not exclusive wallet capabilities.

**Why a common evidence stack matters**

Knowledge graphs and verifiable evidence and assurance graphs should
form a core evidence layer of high-performance, safe and compliant
industrial AI infrastructures. Knowledge graphs connect meaning;
evidence graphs preserve authenticated sources; assurance graphs connect
claims and evidence to requirements and the reasons for accepting a
decision. Business wallets can supply the credentials for this
infrastructure. Most relationships may be supported by ordinary
electronic attestations of attributes (EAAs); selected relationships
need qualified attestations (QEAAs) where the applicable policy requires
them. The paper proposes one W3C VCDM 2.0 profile with RDF-based Data
Integrity proofs for both levels, so a shared graph and verification
pipeline can preserve their different assurance properties. This
requires an eligible qualified profile and qualified issuance; using the
same format does not itself confer qualification. The result would
support reusable, machine-checkable evidence for Trusted AI, trusted
industrial AI and trusted physical AI. It would not, by itself, prove
that evidence is true or an AI system is safe or compliant.

**1 Citizen presentations and industrial evidence graphs**

A transaction presentation can establish a person's eligibility, company
identity or an employee's mandate. SD-JWT VC and mdoc support these
exchanges under the applicable disclosure and holder-binding profile
\[2--4\]. Retention and reuse depend on the workflow; neither format is
restricted to a citizen presenting a credential once.

An industrial evidence graph has a further lifecycle. A battery passport
links supplier, carbon-footprint, recycling, test and verification
records from different issuers. Customs and aerospace designs likewise
combine evidence for a shipment or machine decision. The relying party
must preserve sources, meanings and versions. Selected identity or
representation relationships may require qualified assurance; ordinary
product and process evidence can remain non-qualified. Both should
coexist in the graph, with assurance visible to policy. Four
requirements follow:

- **Meaning after combination.** Shared identifiers and agreed semantics
  distinguish a battery model from a batch, or a test result from legal
  status. Other formats can provide these through explicit identifiers
  and governed mappings; merging field names without agreed meaning is
  insufficient.

- **Attribution after combination.** Each claim must remain bound to the
  issuer-authenticated source. A graph-native design preserves a
  recoverable signed snapshot. A source-backed design retains the
  original signed credential and the evidence needed to verify its
  mapping.

- **Repeated machine verification.** Suppliers, manufacturers, auditors
  and automated systems may reuse evidence. The verification schedule is
  a policy decision based on trust boundaries, integrity, status and
  freshness; every local read need not repeat every signature check.

- **Authority under the decision policy.** Identity, mandates and
  accreditation scope establish who may make a claim. Policy and the
  qualified issuance scheme determine which attestations require and can
  obtain qualification. The proposed common EAA/QEAA stack shares a data
  model, graph-proof profile and pipeline, while checking each qualified
  provider, trust information, scope, status and issuance conditions.
  Seamless processing preserves the different legal assurance levels.

**Ordinary attestations can far outnumber qualified attestations.** In
many industrial and AI evidence designs, ordinary EAAs can greatly
exceed QEAAs: batch declarations, test results, logistics events and
signed AI-evaluation records multiply per asset, event or model version,
while qualified identity, mandates and operating permissions can be
reused. The paper's battery scenario assumes 10--100 million
self-asserted credentials against about 10,000 qualified credentials,
one qualified credential per 1,000--10,000 ordinary credentials; this is
an illustrative workload, not a measured market ratio \[1\]. The mix
depends on the use case: Spherity's author-provided research estimate is
1 QEAA per 5 ordinary EAAs in high-risk use cases, critical
infrastructure, regulated industries and sensitive processes \[1\].

Industry already builds on linked-data standards: GS1 EPCIS 2.0 supports
JSON-LD and RDF integration \[24\]; UNTP's pre-production profile uses
W3C VCDM 2.0 and JSON-LD for product passports, conformity and
traceability credentials, with enveloping proofs \[25\]; Siemens Graph
Studio offers RDF-based enterprise knowledge graphs for AI agents
\[26\]. Graph facts and EPCIS events are not automatically EAAs: they
must be issued as attestations to count as such. As AI knowledge graphs
expand, we expect substantially greater volumes and reuse of attestable
evidence; these examples establish technical uptake, not a measured
EAA/QEAA growth rate. QEAA credential-format standardisation should
therefore accommodate RDF, JSON-LD and W3C VCDM interoperability, shared
identifiers, preservation of source proofs, mixed assurance levels and
repeated machine verification, so ordinary and qualified evidence can
interoperate across workloads with different assurance mixes.

**Foundational assurance is a dependency requirement.** If policy
requires a QEAA for an identity, mandate or licence-to-operate
relationship, an ordinary EAA at that point cannot meet the requirement.
Every conclusion depending on that link then fails the required
assurance level. If all decisions rely on the same deficient foundation,
the assurance claim for the entire decision graph collapses for that
purpose; valid signatures elsewhere cannot repair the missing authority
assurance. This does not require every edge to be qualified or
invalidate independent evidence. Intersecting relationships are a
recurring pattern in industrial digital interactions, making a common,
simple credential profile especially important for expressing
dependencies and checking assurance consistently.

**Hybrid signatures and post-quantum cryptography (PQC).** A
cryptographic hybrid differs from nesting credential formats. Combining
a traditional signature with a post-quantum signature can increase proof
size, key-management work and verification steps; mixed and nested
credential formats add more combinations to implement and test. W3C Data
Integrity already supports multiple digital signatures through unordered
proof sets and ordered proof chains \[6, 22\]. These can carry multiple
proofs without nesting credential formats, but do not alone constitute a
secure hybrid scheme or a post-quantum guarantee. A hybrid profile must
define supported cryptosuites, key and credential bindings, which
components must verify, and protection against proof removal or
downgrade. Where policy requires both signatures, it must detect a
missing proof; accepting either is insufficient \[23\]. A common format
reduces integration variation; cryptographic costs, post-quantum suite
validation and qualified-profile eligibility still need separate
treatment. The paper's existing timings do not measure these hybrid
paths.

**2 What a graph proof covers**

W3C VCDM 2.0 provides a credential data model; JSON-LD can express its
linked-data claims. The recommendation here concerns an RDF-based Data
Integrity suite, not every W3C VC or Data Integrity mechanism \[5, 6\].
At ingestion, the verifier expands under approved contexts,
canonicalises the credential and proof configuration, and verifies the
issuer's signature. For later verification from a graph store, it
reconstructs the same proof input from the preserved source snapshot and
original graph positions. An arbitrary isolated statement cannot be
verified with a full-credential proof without that snapshot.

SD-JWT VC authenticates a protected JWT and commitments to disclosed
claims; mdoc authenticates document elements through its issuer-signed
structure and digests. Those proofs remain useful for retained evidence
if their source inputs and interpretation are preserved. They do not
automatically authenticate an application's subsequent graph projection.
Three distinctions matter:

1.  **The source-to-graph binding.** A source-backed verifier
    authenticates the original credential and validates the mapping to
    the stored statement. If an unpinned context changes, an unchanged
    envelope signature can still verify while a fresh expansion changes.
    A governed profile can prevent acceptance by fixing and
    authenticating the interpretation inputs. The application must use
    the verified view in either architecture.

2.  **Nested processing and cost.** Putting JSON-LD inside an SD-JWT
    requires envelope processing and a controlled route from disclosed
    claims to graph statements. Figure 2 shows the practical steps. In
    the paper's 146-quad fixture, the stored graph-proof check took
    about 0.28 ms; envelope processing with fresh expansion took 1.06
    ms. Including issuance and ingestion, the graph path became cheaper
    from the fifth additional check. A protected cached mapping is
    another valid design; the envelope-only timing of 0.25 ms excluded
    checks of that mapping and its graph binding.

![Comparison of graph-native verification with SD-JWT unnesting and
source-to-graph verification, including timing
boundaries](media/media/image1.png){width="5.905511811023622in"
height="6.766621828521435in"}

**Figure 2.** A machine checking the same stored battery claim through
two architectures. Unnesting includes authentication, disclosure
reconstruction and controlled interpretation; decoding alone proves
nothing. The displayed timings cover prototype portions of the process,
not all steps or complete security checks. A cached mapping can replace
fresh expansion only under a policy protecting its source binding,
freshness and status. Source: paper \[1\], Sections 5.2--5.5;
explanatory diagram added in this edition.

![figure 3 cost per
check](media/media/fc8ac39fb12a4e2a4496d20bc7e890c99313e52b.png){width="6.299212598425197in"
height="2.7709273840769906in"}

**Figure 3.** Prototype times per additional verification, by credential
size. The orange path verifies the retained envelope and freshly expands
its payload; comparison with a cached graph is outside that timed path.
The blue path retrieves and verifies the stored credential and proof
inputs. At 146 quads, the separately measured envelope-only path took
0.25 ms, excluding validation of the cached view and source binding.
Source: paper \[1\], Table 3.

![figure 4 cost and
reuse](media/media/bb72ba1f6ce137966e2316a54f999260cfdae6b4.png){width="6.299212598425197in"
height="2.7709273840769906in"}

**Figure 4.** Cumulative processing and per-check costs from the full
paper, including the envelope-only alternative. The graph path costs
more initially and crosses over against fresh expansion at 4.24
additional checks for the 146-quad fixture. The dashed envelope-only
curve assumes a trusted cached mapping and excludes its validation.
These are prototype processing costs, not complete service latencies.
Source: paper \[1\], Figure 4.

**Disclosure and confidentiality still matter.** Industrial evidence may
contain sensitive process information, personal data or commercially
confidential measurements. Access control, selective disclosure and
appropriately scoped references remain relevant. The separate library
comparison found faster SD-JWT presentation verification than the tested
Data Integrity selective-disclosure path, but the implementations and
checks differ. It is not a universal ranking of formats.

**3 Qualified authority and the claims it supports**

![figure 5 battery
evidence](media/media/42ae4c799ab2bfd93451b9050679b1e2b76b45ea.png){width="6.299212598425197in"
height="4.124645669291339in"}

**Figure 5.** The battery-passport design distinguishes content,
evidence links and authority checks. A valid mandate and accredited
issuer do not by themselves authenticate the exact reported
carbon-footprint class. The diagram includes a content attack that can
remain possible even when authority attestations are qualified. Source:
paper \[1\], Figure 6.

Qualifying selected authority attestations can support many ordinary
product and process credentials. The paper's battery scenario assumes
about 10,000 authority credentials supporting 10--100 million content
credentials annually; these are illustrative workload volumes. Its
attack model also includes content substitutions and joint attacks. A
genuine manufacturer with a valid mandate can issue an incorrect class,
and a verification statement covering only the method may not bind that
class. Qualification does not propagate automatically through a link.
Article 45b gives the specified attestations legal effect under its
conditions; it does not make every downstream claim correct \[7\].

The format request is narrower: make an appropriate graph-proof profile
eligible for qualified issuance, so ordinary EAAs and required QEAAs can
use one representation, graph store and verification pipeline. This
avoids making the application switch credential interpretation solely
because one relationship needs a higher assurance level. It does not
remove qualified-provider or lifecycle checks. Alternatively, an
organisation can retain compliant source credentials, operate their
verifiers and govern the mappings into its graph. That introduces
additional integration and audit obligations, rather than an automatic
loss of assurance.

**4 Three uses and a common evidence requirement**

- **Battery passports and supply-chain compliance.** From 18 February
  2027, Article 77 requires a battery passport for each electric-vehicle
  battery, light-means-of-transport battery and industrial battery above
  2 kWh placed on the market or put into service \[8\]. The paper's
  million-unit manufacturer scenario assumes 10--100 million linked
  credentials annually. The reporting decision needs evidence for the
  reported class as well as the applicable issuer, mandate and
  accreditation checks.

- **E-commerce customs review.** The paper reconstructs an
  evidence-graph design informed by published customs material, a public
  DHS SVIP demonstration in 2021 and trade identity specifications
  \[9--13\]. It links product, order, invoice, packing and transport
  evidence, then adds a worked conformity chain for children's sleepwear
  \[14\]. The complete design is not asserted to be an agency's
  production deployment. Verified attribution helps detect
  impersonation; a genuinely issued false declaration still needs
  corroboration, content checks or examination.

- **An AI safety supervisor in aerospace.** A deterministic supervisor
  evaluates proposed maintenance actions against a verified requirements
  graph. It can check evidence at load and again when policy requires.
  The cited 3 ms versus 16 ms for 20 supporting credentials is an
  arithmetic projection from individual checks, not a measured
  end-to-end supervisor result, worst-case execution bound or certified
  safety deadline. Policy evaluation and status checks need separate
  budgets; immediate protective functions remain outside the
  graph-dependent path.

The common requirement is a verifiable connection from a decision input
to its source, interpretation, version and authority. Graph-native
verification provides one way to achieve it. A properly governed
source-backed architecture provides another. Their costs depend on what
is retained, checked and reused.

**5 What is being asked**

1.  **W3C.** Develop a high-assurance VCDM 2.0 profile with RDF-based
    Data Integrity proofs: fixed contexts and processing, rejection of
    lost terms, source-snapshot preservation, graph admission rules,
    work and execution limits, permitted cryptosuites, status,
    organisational key binding, and conformance tests.

2.  **ETSI ESI.** Extend the relevant issuance and presentation
    profiles, including TS 119 472-1 clause 7 \[15\], with precise
    graph-proof, certificate and key-binding, status, context and
    security requirements.

3.  **European Commission.** Consider referencing the completed profile
    for the qualified and public-source attestations in scope and in
    future European Business Wallet rules, with scheme-specific
    adaptations. Company identity and representation are relevant;
    accreditation and autonomous-agent mandates require their applicable
    authority and scheme.

4.  **Sector bodies.** Test the profile in supply-chain and industrial
    workflows, including confidential evidence, retained-source
    alternatives, status changes and cross-border trust requirements.

The proposal adds a graph-proof option alongside existing profiles.
Format eligibility, issuer qualification and successful validation are
separate conditions.

**6 The formats side by side**

The table compares verification architectures and their conditions. The
graph-store timings are the paper's run-3 medians on one thread. The
separate one-shot results and attack tests use different implementations
and checks \[16, 17\]. They do not establish a universal performance or
security ranking.

The rows distinguish graph semantics, source retention, repeated
verification, presentation features and qualification. A positive result
depends on the stated profile and operating conditions.

  -------------------------------------------------------------------------------------------
  **Property**    **SD-JWT VC**   **ISO mdoc**           **JSON-LD inside   **VCDM 2.0 with
                                                         SD-JWT**           RDF-based Data
                                                                            Integrity**
  --------------- --------------- ---------------------- ------------------ -----------------
  Meaning in a    Needs shared    Needs a mapping from   Linked-data        Shared RDF
  graph           identifiers and typed document         content plus       semantics;
                  an agreed       elements               governed context   profile must
                  mapping from                           and disclosure     reject undefined
                  claims                                 rules              or lost terms

  What is         Protected JWS   Issuer-signed          Envelope input;    Canonical
  authenticated   input and       structure and element  graph              credential
                  disclosure      digests                interpretation     dataset and proof
                  commitments                            needs a controlled configuration
                                                         binding            

  Verification    Retain the      Retain source          Retain token,      Recover the full
  after storage   source and      verification evidence; disclosures and    source snapshot,
                  required        validate the graph     interpretation     graph positions,
                  disclosures;    mapping                inputs; check the  proof options and
                  validate the                           source-to-view     signature
                  graph mapping                          binding            

  Additional      This            This graph-store path  1.06 ms with fresh 0.28 ms; higher
  check at 146    graph-store     not measured           expansion; 0.25 ms initial cost;
  quads in the    path not                               envelope-only,     cheaper than
  paper           separately                             excluding          fresh expansion
                  measured                               cached-view checks from check 5

  Qualified       Eligible under  Eligible under the     Eligibility        Common
  authority on    the applicable  applicable issuance    depends on the     graph-proof path
  the path        issuance        profile; map and       complete profile   possible if a
                  profile; map    validate as required   and scheme, not    qualified profile
                  and validate as                        nesting alone      becomes eligible
                  required                                                  

  Selective       Claim           Selected data elements Claim disclosure   Separate suites
  disclosure      disclosures     and their              plus rules         such as
                  with issuer     issuer-authenticated   protecting graph   ecdsa-sd-2023 or
                  commitments     digests                interpretation     BBS; not provided
                                                                            by every
                                                                            graph-proof suite

  Holder binding  Key binding     Device binding and     Inherits the       Presentation and
  and linkability where required; linkability depend on  envelope's         suite dependent;
                  reused issuer   the profile            bindings; mapping  full-credential
                  JWT can link                           must preserve them proofs do not
                  presentations                          where relevant     imply
                                                                            unlinkability

  Separate        0.30 ms, tested 0.27 ms, tested        Nested path not    0.53 ms; subset
  one-shot study  exchange        exchange               measured in that   re-signed in that
  \[16\]                                                 study              experiment, so
                                                                            authentication
                                                                            guarantees differ

  Security        Allowed         Issuer structure,      Envelope checks    Controlled
  controls        algorithms, key element digests,       plus fixed         loader, context
                  and disclosure  device/session checks  interpretation and checks, graph
                  checks, status  and policy             verified           admission, work
                  and policy                             source-to-graph    and execution
                                                         binding            limits at
                                                                            relevant
                                                                            processing steps

  Current         Referenced      Referenced profiles,   No automatic       No graph-proof
  qualified       profiles, with  with applicable        eligibility from   profile
  issuance        applicable      conditions             using an SD-JWT    referenced in the
  baseline        conditions                             wrapper            examined baseline

  Architectural   Presentations   Presentations or       Useful when        Supports
  fit             or governed     governed source-backed interoperability   graph-native
                  source-backed   graph use              justifies its      reuse under the
                  graph use                              retention and      specified storage
                                                         mapping            and processing
                                                         obligations        conditions
  -------------------------------------------------------------------------------------------

**Why a graph-proof profile is useful for repeated industrial
verification.** The benefit is a common issuer-authenticated
representation for retained graph evidence, subject to explicit storage,
processing and legal conditions:

- **The proof authenticates the graph statements and proof
  configuration.** A preserved signed snapshot can be recovered from the
  store for verification. This requires lossless source boundaries and
  original graph positions, not an arbitrary union of statements.

- **The tested reuse path avoids fresh JSON-LD expansion.** It still
  retrieves the snapshot, canonicalises, hashes and verifies.
  Source-backed systems can also cache verified mappings under a policy
  that protects the view, binding, freshness and status. The measured
  envelope-only check does real signature verification; its timing omits
  the cached-view checks.

- **One profile can simplify a chosen verification path.** Making it
  eligible for qualified attestations would let an organisation apply
  the same graph-proof rules to those attestations and ordinary
  evidence. Mixed-format systems remain possible, with additional
  verifiers and governed bindings.

- **Nesting needs a justified purpose.** An envelope can support
  interoperability or presentation requirements. Using it only to
  transport graph content adds retained source material and
  interpretation rules; it does not turn the envelope signature into a
  direct proof over the stored graph.

- **Resource bounds must be enforced.** Graph canonicalisation occurs
  during verification as well as issuance. Input restrictions, fixed
  loaders, work budgets and interruptible execution limits are needed.
  Library defaults or a valid-looking issuer identifier do not establish
  a safe execution deadline.

For repeated verification of retained graph evidence, the paper supports
a qualified graph-proof option. For other workloads, existing
presentation formats or a governed mixed architecture may be
appropriate. The policy and complete processing path determine the
choice.

**7 What the evidence is**

The manuscript supplies formal models, worked designs and prototype
benchmarks against an in-memory quad store: 500 credentials per size,
17--574 quads, with selected reference-library and adversarial-input
checks. Results are conditional on the stated processing paths, one
machine and synthetic workloads. The supplied publication package
contains the manuscript and figures, but not the separately referenced
benchmark code or raw data. This review checks consistency with the
reviewed version 1.3; it does not independently reproduce the
measurements or validate a production deployment.

**8 Why now**

The EUDI issuance baseline references the relevant SD-JWT VC and mdoc
profiles through clauses 2--6 of ETSI TS 119 472-1; clause 7's W3C VCDM
material is outside that reference. The rules anticipate W3C support
when new profiles are available \[18--20\]. The European Business Wallet
remains a legislative proposal \[21\]. These developments create a
standards opportunity to define a graph-proof option for organisational
evidence. This is a specific profile-eligibility issue, not a rule that
EUDI credentials are only for natural persons or that W3C credentials
are prohibited in business.

**9 Graphs as core evidence infrastructure for Trusted AI**

Our architectural position is that knowledge graphs and verifiable
evidence and assurance graphs belong at the core of high-performance,
safe and compliant AI infrastructures. A knowledge graph expresses what
entities and relationships mean. A verifiable evidence graph binds
assertions to authenticated issuers, source snapshots and versions. An
assurance graph links a system claim to the evidence, requirements,
assumptions and reasoning that justify accepting it. These can be
complementary views over a shared information architecture; a graph edge
does not automatically establish an assurance conclusion.

This connects the paper to Spherity's research on **Trusted AI, trusted
industrial AI and trusted physical AI**. An AI agent can trace a
proposed action to its supporting evidence and authority. Industrial AI
can link products, process conditions, tests and compliance requirements
across organisations. Physical AI, such as robots or autonomous
machines, can link permitted actions and operating limits to current
evidence and authorised actors. Credential checks support this
architecture alongside the safety engineering, monitoring and controls
needed for physical action.

1.  **Use one graph while preserving different assurance levels.** An
    ordinary EAA may report a component's test result, while policy
    requires a QEAA for an identity or representation relationship used
    to accept it. Both should pass seamlessly through the proposed
    common profile. The decision engine still checks the assertion
    covered, the issuer's authority and current status. Qualified
    authority does not qualify the test result, other graph edges or the
    AI output. Full-credential graph-proof verification still needs
    recoverable signed source snapshots.

2.  **Make the justification for a decision inspectable.** Connect a
    proposed action to the relevant requirement, the evidence supporting
    it and any assumptions or unresolved conflicts. For a factory
    decision, this might mean showing which test supports a component's
    acceptance and which mandate authorises the accepting agent.
    Cryptographic verification authenticates attribution and integrity;
    technical validation and the decision policy determine whether the
    evidence is sufficient. Record derived conclusions as derived, with
    their rule or model version and supporting sources, rather than
    presenting them as issuer-signed facts.

3.  **Design performance and safety together.** Shared semantics and
    reusable verified evidence can reduce repeated interpretation and
    support efficient queries. The paper measures specific verification
    paths, not AI throughput or operational safety. Set freshness rules,
    revocation handling and the verification schedule, then benchmark
    the complete decision path. Safety-critical consumers also need
    resource limits, runtime controls and a defined response to missing
    or stale evidence. Physical systems need a designed safe response
    when verification is unavailable.

The recommendation is to make a suitable W3C VCDM 2.0 graph-proof
profile eligible for the required qualified attestations. A common
credential format is especially important where industrial evidence
relationships intersect: missing policy-required foundational QEAAs
defeat every dependent decision path, potentially the entire graph. Data
Integrity already supports multiple signatures through proof sets and
chains, but PQC hybrids still need validated suites, key and credential
bindings, mandatory-component checks and downgrade protection \[6, 22,
23\]. More signatures do not elevate an EAA to a QEAA. One stack can
simplify integration while preserving assurance levels; safety and
compliance still require sound engineering and governance.

Contact: carsten.stoecker@spherity.com. The author is chief executive of
Spherity GmbH, a verifiable-credential software provider that
participated in the DHS pilot informing the customs example. The full
paper and figures are licensed under CC BY 4.0. This edition aligns the
PQC and foundational-assurance guidance with the reviewed full paper.

**References**

\[1\] C. Stöcker, Proofs over Statements in Verifiable Evidence Graphs
for the European Business Wallet, reviewed version 1.3, 9 November 2026,
CC BY 4.0. Spherity Research repository,
https://github.com/spherity/spherity-research

\[2\] IETF OAuth Working Group, SD-JWT-based Verifiable Digital
Credentials (SD-JWT VC), draft-ietf-oauth-sd-jwt-vc-26, 6 November 2026
(Internet-Draft).
https://datatracker.ietf.org/doc/draft-ietf-oauth-sd-jwt-vc/26/

\[3\] IETF RFC 9901, Selective Disclosure for JSON Web Tokens, November
2025. https://www.rfc-editor.org/rfc/rfc9901

\[4\] ISO/IEC 18013-5:2021, Mobile driving licence (mDL) application.

\[5\] W3C, Verifiable Credentials Data Model v2.0, Recommendation, 15
May 2025. https://www.w3.org/TR/vc-data-model-2.0/

\[6\] W3C, Verifiable Credential Data Integrity 1.0, Recommendation, 15
May 2025. https://www.w3.org/TR/vc-data-integrity/

\[7\] Regulation (EU) No 910/2014 as amended by Regulation (EU)
2024/1183. https://eur-lex.europa.eu/eli/reg/2024/1183/oj

\[8\] Regulation (EU) 2023/1542 (Batteries).
https://eur-lex.europa.eu/eli/reg/2023/1542/oj/eng

\[9\] U.S. Customs and Border Protection, E-Commerce, web page last
modified 6 November 2026, accessed 8 November 2026.
https://www.cbp.gov/trade/basic-import-export/e-commerce

\[10\] GLEIF, vLEI Ecosystem Governance Framework, version 4.0, accessed
8 November 2026.
https://www.gleif.org/en/vlei/introducing-the-verifiable-lei-vlei

\[11\] DHS S&T SVIP, Plug-Fest report, W3C CCG list, 4 March 2021.
https://lists.w3.org/Archives/Public/public-credentials/2021Mar/0022.html

\[12\] Spherity, DHS SVIP Plugfest Demo: E-commerce Digital Twin, video
recordings of the DHS S&T SVIP Interoperability Showcase, March 2021.
https://vimeo.com/540163632 ; https://vimeo.com/524276878

\[13\] W3C Credentials Community Group, Traceability Vocabulary v1.0,
accessed 8 November 2026. https://w3c-ccg.github.io/traceability-vocab/

\[14\] U.S. Consumer Product Safety Commission, Third Party Testing
Guidance, accessed 8 November 2026.
https://www.cpsc.gov/Business\--Manufacturing/Testing-Certification/Third-Party-Testing

\[15\] ETSI TS 119 472-1 V1.2.1 (2026-02).
https://www.etsi.org/deliver/etsi_ts/119400_119499/11947201/01.02.01_60/ts_11947201v010201p.pdf

\[16\] N. Fujie and S. Suzuki, An Empirical Evaluation of Signing and
Verification Performance of Verifiable Credential Formats: A
Cross-Language Benchmark of SD-JWT VC, W3C VCDM, and mdoc,
arXiv:2611.03493v1, 2 November 2026 (preprint).
https://arxiv.org/abs/2611.03493v1

\[17\] N. Fujie and S. Suzuki, A Security Analysis of Verifiable
Credential Verification Pipelines: Attack Surface Arising from
JSON-LD/RDFC Canonicalization Compared with SD-JWT VC and mdoc,
arXiv:2611.04461v1, 3 November 2026 (preprint).
https://arxiv.org/abs/2611.04461v1

\[18\] Commission Implementing Regulation (EU) 2025/1569, consolidated
text of 11 August 2026, Arts. 3--4 and Annex II.
https://eur-lex.europa.eu/legal-content/EN/TXT/?uri=CELEX:02025R1569-20260811

\[19\] Commission Implementing Regulation (EU) 2026/1731 of 15 July 2026
as regards applicable standards and specifications.
https://eur-lex.europa.eu/legal-content/EN/TXT/PDF/?uri=CELEX:32026R1731

\[20\] Commission Implementing Regulation (EU) 2026/1735 of 15 July 2026
amending Implementing Regulation (EU) 2025/1569.
https://eur-lex.europa.eu/legal-content/EN/TXT/PDF/?uri=CELEX:32026R1735

\[21\] European Commission, Proposal for a Regulation on European
Business Wallets, COM(2025) 838.
https://eur-lex.europa.eu/legal-content/EN/TXT/?uri=CELEX:52025PC0838

\[22\] W3C, Data Integrity EdDSA Cryptosuites v1.0, Recommendation, 15
May 2025, proof-set and proof-chain test vectors.
https://www.w3.org/TR/vc-di-eddsa/

\[23\] N. Bindel, B. Hale, D. Connolly and F. Driscoll, Hybrid Signature
Spectrums, IETF RFC 9955, July 2026 (Informational).
https://www.rfc-editor.org/rfc/rfc9955.html

\[24\] GS1, EPCIS Standard, Release 2.0, June 2022, Section 10,
JSON/JSON-LD bindings and RDF integration.
https://ref.gs1.org/standards/epcis/2.0.1/

\[25\] UNECE, UN Transparency Protocol, Verifiable Credentials profile
(work in progress; pre-production pilots), accessed 9 November 2026.
https://untp.unece.org/docs/specification/VerifiableCredentials/

\[26\] Siemens, Rapidminer Graph Studio, open W3C standards and AI-agent
context capabilities, accessed 9 November 2026.
https://www.siemens.com/en-us/products/rapidminer/graph-studio/
