FINAL PUBLICATION PACKAGE
Proofs over Statements in Verifiable Evidence Graphs for the European Business Wallet
Version 1.3 — 9 November 2026
Author and copyright: Carsten Stöcker, Spherity GmbH

START HERE
full-paper/main.pdf          Final reviewed full paper, 63 pages
executive-brief/main.pdf     Final reviewed executive brief, 20 pages

Each document folder is self-contained and includes:
- main.tex: final editable LaTeX manuscript; references are embedded.
- figures/: vector PDF figures, with editable SVG originals in figures/source/.
- assets/: the official CC BY 4.0 badge used in the PDFs.
- examples/: complete signed credentials, exact nested token, public verification
  material, fixed contexts, pinned dependencies and executed validation reports.
- README_overleaf.txt: compilation and file instructions.
- Review reports and source/: provenance, original Word references and audit
  evidence. Original Word/extraction files preserve the earlier source record;
  main.tex and main.pdf are the authoritative final publication versions.

BUILD THE DOCUMENTS
Open the relevant document folder. Use pdfLaTeX and run:
  latexmk -pdf -interaction=nonstopmode -halt-on-error main.tex
Alternatively run pdflatex three times. For Overleaf, upload one document
folder's contents and select main.tex with the pdfLaTeX compiler.
Both documents were clean-built from their delivery folders; the results
matched the visually reviewed PDFs. No unresolved references, missing glyphs,
overfull boxes or LaTeX warnings remained.

VALIDATED CREDENTIAL EXAMPLES
Each examples/ folder contains the same complete public verification package,
so either document can compile and its examples can be checked independently.
plain-vc.json has an eddsa-rdfc-2022 Data Integrity proof. nested.sd-jwt wraps
that signed credential in an ES256 SD-JWT; the local profile requires both
proofs. The main runner passed 4 acceptance controls and 13 expected rejections.
The direct Node/OpenSSL audit passed 9 assertions and 8 negative checks.
No private signing keys are included. See examples/README.txt for scope.

With Node.js 24, from either examples/ folder:
  npm ci --ignore-scripts --no-audit --no-fund
  node verify.mjs
  node audit-spec.mjs
The installation downloads the pinned dependencies. Verification then uses
local inputs and a fixed demonstration time of 9 November 2026, 12:00 UTC.
These checks establish example verification behaviour, not QEAA eligibility,
production conformance or reproduction of the original performance benchmark.
The benchmark archive is not supplied, as disclosed in the documents.

LICENCE AND INTEGRITY
The papers and figures are licensed CC BY 4.0, except where otherwise noted.
Copyright 2026 Carsten Stöcker, Spherity GmbH.
https://creativecommons.org/licenses/by/4.0/
Third-party contexts and dependencies retain their supplied licence notices.
The paper licence does not automatically assign a software licence to the
verification scripts. See examples/THIRD-PARTY-NOTICES.txt and licenses/.

PUBLICATION-MANIFEST.json records document and validation metadata.
SHA256SUMS.json covers every other file in this package. The document folders
also preserve their previously verified file manifests. The ZIP itself has
an accompanying SHA-256 checksum file.
